# CETI

## Requirements:
    * Docker host
    * 4 public IP addresses

## Setup
1. Create a configuration `.env` file in the basedir with the following content:

    ```
    IPV4_CETI=<PUBLIC-IP-1>
    IPV4_MTASTS_NOMATCH_SAN=<PUBLIC-IP-2>
    IPV4_MTASTS_UNTRUSTED_MHS=<PUBLIC-IP-3>
    IPV4_MTASTS_EXPIRED_CERT=<PUBLIC-IP-4>
    ZONE=<DNS-ZONE> (e.g. tr03108.example.com)
    DNSSECRET=<DNSSECRET>
    USERNAME=<Choose WEBINTERFACE USERNAME>
    PASSWORD=<Choose WEBINTERFACE PASSWORD>
    LETSENCRYPT_MAIL=<EMAIL-FOR-CERT-BOT>
    MTASTS_EXPIRED_MHS_CERT=<PATH-TO-MTASTS_EXPIRED_MHS_CERT> (e.g. ./keys/filename)
    MTASTS_EXPIRED_MHS_CERT_KEY=<PATH-TO-MTASTS_EXPIRED_MHS_CERT_KEY> (e.g. ./keys/filename)
    ```

2. Build the docker environment:

   ```
   $ docker-compose build
   ```
3. Run CETI:

    ```
    $ docker-compose up
    ```

4. Access the public webinterface:
   
   ```
   https://<PUBLIC-IP-1>
   ```

