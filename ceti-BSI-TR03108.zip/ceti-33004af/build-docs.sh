#! /bin/sh

sphinx-apidoc -f -o doc/source --separate -M ceti
sphinx-apidoc -f -o doc/source --separate -M mailserver
sphinx-apidoc -f -o doc/source --separate -M tlsrpt-https
(cd doc && make html)
