#! /bin/sh

docker build -t ceti-docs:latest .
docker run -v "$PWD/doc:/apps/doc" ceti-docs
