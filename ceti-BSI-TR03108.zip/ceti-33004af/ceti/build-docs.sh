#! /bin/sh

sphinx-apidoc -f -o docs/source/ --separate -M .
(cd docs && make html)


