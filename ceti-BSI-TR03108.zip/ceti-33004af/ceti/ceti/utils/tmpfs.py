import tempfile
from os.path import join

from .python import unique_id


class TmpFileStore():

    def __init__(self):
        self.cwd = tempfile.TemporaryDirectory()
        
    def write(self, data: bytes):
        #self.cwd.name
        filename = join("/tmp/", unique_id())
        with open(filename, "wb") as f:
            f.write(data)
        return filename
