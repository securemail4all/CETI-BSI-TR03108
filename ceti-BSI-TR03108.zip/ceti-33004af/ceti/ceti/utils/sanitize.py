import re

def clean_path(filename):
    return "".join([c for c in filename if c.isalpha() or c.isdigit() or c=='-' or c=='_']).rstrip()

def remove_terminal_control(ansi):
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', ansi)