import re


class FilterableList(list):

    def contains(self, cls):
        return self.first(cls) is not None

    def filter(self, cls):
        return type(self)(item for item in self if isinstance(item, cls))

    def first(self, cls):
        for item in self:
            if isinstance(item, cls):
                return item
        return None


def is_iterable(obj):
    try:
        iter(obj)
    except TypeError:
        return False
    else:
        return True


def flatten_list(l):
    return [item for sublist in l for item in sublist]



def search(dictionary, search_pattern, output=None):
    """
    Search nested dictionaries and lists using a regex search
    pattern to match a key and return the corresponding value(s).
    """
    if output is None:
        output = []

    pattern = re.compile(search_pattern)
    
    for k, v in dictionary.items():
        pattern_found = pattern.search(k)
        if not pattern_found:
            if isinstance(v, list):
                for item in v:
                    if isinstance(item, dict):
                        search(item, search_pattern, output)
            if isinstance(v, dict):
                search(v, search_pattern, output)
        else:
            if pattern_found:
                output.append(v)

    return output


_count_unique_id=0

def unique_id():
    global _count_unique_id
    _count_unique_id += 1
    return "id_" + str(_count_unique_id)
