"""
Functions and utities for checking TLSRPT according to
`RFC 8460 <https://datatracker.ietf.org/doc/html/rfc8460>`_.
"""

from typing import Optional

import email
import gzip
import json
import logging

from public import public

from .types import TxtRecord

logger = logging.getLogger(__name__)


@public
def tlsrpt_validate_dnsrecord(record: TxtRecord):
    """
    Validate the given DNS TXT resource record. Return true when the given
    record complies to `RFC 8460 <https://datatracker.ietf.org/doc/html/rfc8460>`_, section 3.

    Args:
        record (TxtRecord): The DNS TXT resource record to check.

    Returns:
        A bool indicating if the TxtRecord complies to
        `RFC 8460 <https://datatracker.ietf.org/doc/html/rfc8460>`_.
    """
    if "v" not in record or "rua" not in record:
        return False

    if record["v"] != "TLSRPTv1":
        return False

    # if not all(map(lambda x: x.startswith("mailto:"), record["rua"])):
    #     return f"DNS Record {record.text} nutzt nicht ausschließlich mailto:"

    return True


@public
def tlsrpt_extract_report(msg: bytes):
    """
    Interpret the given bytes as email according to
    `RFC 5322 <https://datatracker.ietf.org/doc/html/rfc5322.html>`_/`RFC 6532 <https://datatracker.ietf.org/doc/html/rfc6532.html>`_ and try to find
    and extract an attached TLS report.

    Args:
        msg (bytes): The bytes of the email message received

    Returns:
        A tuple (domain (str), dict) or (None, None). If a TLS report was found, the tuple
        contains the sender's domain name and the actual tls report parsed as dict. Otherwise the
        tuple is empty.
    """
    mail = email.message_from_bytes(msg)

    mail_from = email.utils.getaddresses(mail.get_all("From", []))

    if len(mail_from) == 0:
        return None, None

    domains = set(map(lambda addr: addr[1].split("@", 1)[-1], mail_from))
    if len(domains) == 0:
        logger.error("Error parsing From: header of TLSRPT mail")
        return None, None

    if len(domains) != 1:
        logger.warning("From: header contains addresses from multiple domains")
    domain = domains.pop()

    payload = mail.get_payload()
    attachment = None

    if isinstance(payload, list):
        attachment = next(
            filter(
                lambda x: x.get_content_type().startswith("application/tlsrpt"), payload
            ),
            None,
        )
    elif mail.get_content_type().startswith("application/tlsrpt"):
        attachment = mail

    if not attachment:
        return None, None
    report = attachment.get_payload(decode=True)

    if attachment.get_content_type().endswith("+gzip"):
        report = gzip.decompress(report)

    return domain, json.loads(report)


@public
def tlsrpt_validate_report(report: dict, organization_name: Optional[str]):
    """
    Validate if the given report complies to
    `RFC 8460 <https://datatracker.ietf.org/doc/html/rfc8460>`_,
    section 4.4. Check if the given report represented as `dict`
    matches the following criteria (quoted from RFC):


        Aggregate reports contain the following fields:

        *  Report metadata:

            *  The organization responsible for the report
            *  Contact information for one or more responsible parties for the
               contents of the report
            *  A unique identifier for the report
            *  The reporting date range for the report

        *  Policy, consisting of:

            *  One of the following policy types: (1) the MTA-STS Policy
               applied (as a string), (2) the DANE TLSA record applied (as a
               string, with each RR entry of the RRset listed and separated by
               a semicolon), and (3) the literal string "no-policy-found", if
               neither a DANE nor MTA-STS Policy could be found.
            *  The domain for which the policy is applied
            *  The MX host

        *  Aggregate counts, comprising result type, Sending MTA IP,
           receiving MTA hostname, session count, and an optional additional
           information field containing a URI for recipients to review
           further information on a failure type.

    Args:
        report (dict): The TLS report in question represented as dict.
        organization_name (Optional[str]): An organization name may be specified that `must`
            be present in the report.
    Returns:
        A bool value indicating if the report complies to the RFC.
    """

    def validate_policy(policy):
        return (
            "policy" in policy
            and "policy-type" in policy["policy"]
            and "policy-domain" in policy["policy"]
            and "summary" in policy
            and "total-successful-session-count" in policy["summary"]
            and "total-failure-session-count" in policy["summary"]
        )

    return (
        "organization-name" in report
        and (
            organization_name == report["organization-name"]
            if organization_name is not None
            else True
        )
        and "contact-info" in report
        and "report-id" in report
        and "date-range" in report
        and "policies" in report
        and all(map(validate_policy, report["policies"]))
    )
