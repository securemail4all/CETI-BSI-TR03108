import subprocess
import logging
import json
import re
import hashlib
import tempfile

from shlex import quote
from dataclasses import dataclass
from importlib.metadata import version

from public import public

from ceti.api.types import DnsVizProbeScanResult, DNSSecResult


logger = logging.getLogger(__name__)


@public
def dnssec_analyze(probe: DnsVizProbeScanResult) -> DNSSecResult:
    """Evaluate DNSViz probe.

    Takes a DNSViz probe and performs all
    steps to create a ``DNSSecResult``.

    Args:
        probe (dict): probe as returned by ``dnsviz_probe_rdtype``

    Returns:
        DNSSecResult: the evaluated DNSViz probe
    """

    return DNSSecResult(
        probe=probe,
        domain=probe.domain,
        rdtype=probe.rdtype,
        dnsviz_version=probe.dnsviz_version,
        issues=dnsviz_issues(probe),
        status=dnsviz_status(probe),
        graph=dnsviz_graph(probe),
        compliant=dnsviz_is_compliant(probe),
    )


@public
def dnsviz_probe_rdtype(domain: str, rdtype: str) -> DnsVizProbeScanResult:
    """Performs a DNS lookup using DNSViz probe.

    Takes a domain name as input and performs a series of
    queries to recursive DNS servers. The results are
    parsed into a dict.

    Args:
        domain (str): domain name
        rdtype (str): DNS record type (A, AAAA, SRV, ...)

    Returns:
        dict: DNSViz probe output parsed as dict
    """
    assert isinstance(domain, str)
    assert len(domain) > 0

    assert isinstance(rdtype, str)
    assert len(rdtype) > 0

    viz = SubprocessDNSViz()
    return DnsVizProbeScanResult(
        domain=domain,
        rdtype=rdtype,
        dnsviz_version=dnsviz_version(),
        result=viz.probe_rdtype(domain, rdtype),
    )


@public
def dnsviz_mx(probe: DnsVizProbeScanResult) -> list:
    """Extracts MX data from a DNSViz probe.

    Args:
        probe (dict): probe as returned by ``dnsviz_probe_rdtype``

    Returns:
        list: list of MX domains or empty list when no MX data was found in the probe
    """
    assert isinstance(probe, DnsVizProbeScanResult)
    return extract_mx_from_probe(probe.result)


@public
def dnsviz_srv(probe: DnsVizProbeScanResult) -> list:
    """Extracts SRV data from a DNSViz probe.

    Args:
        probe (dict): probe as returned by ``dnsviz_probe_rdtype``

    Returns:
        list[tuple]: list of SRV data tuples (host, port) or empty list when no SRV data was found in the probe

    """
    assert isinstance(probe, DnsVizProbeScanResult)
    return extract_srv_from_probe(probe.result)


@public
def dnsviz_txt(probe: DnsVizProbeScanResult) -> list:
    """Extracts TXT data from a DNSViz probe.

    Args:
        probe (dict): probe as returned by ``dnsviz_probe_rdtype``

    Returns:
        list[tuple]: list of TXT data or empty list when no TXT data was found in the probe

    """
    assert isinstance(probe, DnsVizProbeScanResult)
    return extract_txt_from_probe(probe.result)


@public
def dnsviz_issues(probe: DnsVizProbeScanResult) -> list:
    """Extracts all warnings and errors from a DNSViz probe.

    Takes a DNSViz probe and returns a list of all DNSSec
    related errors and warnings.

    Args:
        probe (dict): Probe as returned by ``dnsviz_probe_rdtype``

    Returns:
        list[DnsIssue]: list of SRV issues or empty list when no issue was found
    """
    assert isinstance(probe, DnsVizProbeScanResult)
    return extract_issues_from_probe(probe.result)


@public
def dnsviz_status(probe: DnsVizProbeScanResult) -> str:
    """Extracts DNSViz status for a DNSViz probe.

    Takes a DNSViz probe and returns the DNSSec status
    for each DNS label (., .com., .com.google, .com.google.www).

    The status can be one of the following:
        - NOERROR: DNSSEC is ok
        - ERROR: DNSSEC reply with security related problems
        - NXDOMAIN: There is no such domain name

    Args:
        probe (dict): Probe as returned by ``dnsviz_probe_rdtype``

    Returns:
        str: list of status for each DNS label
    """
    assert isinstance(probe, DnsVizProbeScanResult)

    status = extract_status_from_probe(probe.result)
    # first check for NXDOAMIN
    for s in status:
        if s["zone_status"] == "NXDOMAIN":
            return "NXDOMAIN"
    # then test for all other errors
    for s in status:
        if s["zone_status"] != "NOERROR" or not (
            s["delegation_status"] is None or s["delegation_status"] == "SECURE"
        ):
            return "ERROR"

    return "NOERROR"


@public
def dnsviz_graph(probe: DnsVizProbeScanResult) -> bytes:
    """Create an PNG image from a DNSViz probe.

    Takes a DNSViz probe and creates a visual graph
    of the probe as a PNG image

    Args:
        probe (dict): Probe as returned by ``dnsviz_probe_rdtype``

    Returns:
        bytes: visual graph as PNG image
    """
    assert isinstance(probe, DnsVizProbeScanResult)

    viz = SubprocessDNSViz()
    return viz.graph(probe.result)


@public
def dnsviz_version() -> str:
    """Returns the software version of DNSViz.

    Returns:
        str: version of DNSViz
    """
    viz = SubprocessDNSViz()
    return viz.version()


@public
def dnsviz_is_compliant(probe: DnsVizProbeScanResult) -> bool:
    """Checks if DNSViz probe is compliant with BSI TR-03108-1.

    Takes a DNSViz probe and checks if the given DNSSec response is
    secure and compliant with BSI TR-03108-1.

    Args:
        probe (dict): Probe as returned by ``dnsviz_probe_rdtype``

    Returns:
        bool: true if compliant else false
    """
    assert isinstance(probe, DnsVizProbeScanResult)

    issues = dnsviz_issues(probe)
    status = dnsviz_status(probe)
    if status != "NOERROR":
        return False
    for i in issues:
        if i.is_error:
            return False
    return True


class SubprocessDNSViz:
    def __init__(self):
        self.cwd = tempfile.TemporaryDirectory()

    def _exec(self, cmdline, stdin=None):
        logger.debug("Execute %s", cmdline)

        try:
            proc = subprocess.run(
                cmdline,
                cwd=self.cwd.name,
                capture_output=True,
                check=True,
                shell=True,
                timeout=60,
                input=stdin,
            )

            stdout = proc.stdout
            return stdout
        except subprocess.CalledProcessError as e:
            logger.error(stdin)
            logger.exception(
                "error calling process: %s %s", e.stdout, e.stderr, exc_info=e
            )
        return ""

    def version(self):
        return version("dnsviz")

    def probe_rdtype(self, domain, rdtype):

        cmd = "dnsviz probe -4 -A -a . -R {} {}".format(quote(rdtype), quote(domain))

        ret = self._exec(cmd)
        return json.loads(ret.decode("utf-8"))

    def grok(self, probe_result):
        cmd = "dnsviz grok"
        probe = json.dumps(probe_result).encode("utf-8")
        ret = self._exec(cmd, stdin=probe)
        return json.loads(ret.decode("utf-8"))

    def graph(self, probe_result):
        cmd = "dnsviz graph -Tpng"
        probe = json.dumps(probe_result).encode("utf-8")
        ret = self._exec(cmd, stdin=probe)
        return ret


def _search_in_grok(grok, func):
    def step(json):
        if type(json) is dict:
            return [func(json)] + sum([step(item) for key, item in json.items()], [])
        elif type(json) is list:
            return sum([step(item) for item in json], [])
        else:
            return []

    return sum([s for s in step(grok) if s is not None], [])


@dataclass
class DnsIssue:
    label: str
    is_error: bool
    code: str
    description: str


def _extract_issues(json, label):
    i = []
    for level in ["warning", "warnings", "error", "errors"]:
        if level in json:
            for event in json[level]:
                i.append(
                    DnsIssue(
                        label=label,
                        is_error=level.startswith("err"),
                        code=event["code"],
                        description=event["description"],
                    )
                )
    return i


def extract_issues_from_probe(probe):
    issues = []
    grok = SubprocessDNSViz().grok(probe)
    for label, node in grok.items():
        issues.extend(_search_in_grok(grok, lambda json: _extract_issues(json, label)))
    return issues


def _extract_mx(json):
    result = []
    if json.get("id", "").endswith("/IN/MX"):
        if "rdata" not in json:
            return result
        for mx in json["rdata"]:
            group = re.match("^[0-9]+\s+(.*)\.$", mx)
            result.append(group[1])
    return result


def _extract_txt(json):
    result = []
    if json.get("id", "").endswith("/IN/TXT"):
        if "rdata" not in json:
            return result
        for txt in json["rdata"]:
            result.append(txt)
    return result


def _extract_srv(json):
    result = []
    if json.get("id", "").endswith("/IN/SRV"):
        if "rdata" not in json:
            return result
        for srv in json["rdata"]:
            group = re.match("^([0-9]+) ([0-9]+) ([0-9]+)+\s+(.*)\.$", srv)
            result.append((group[4], int(group[3])))
        return result
    return result


def extract_mx_from_probe(probe: dict) -> list:
    grok = SubprocessDNSViz().grok(probe)
    return list(set(_search_in_grok(grok, lambda json: _extract_mx(json))))


def extract_srv_from_probe(probe: dict) -> list:
    grok = SubprocessDNSViz().grok(probe)
    return list(set(_search_in_grok(grok, lambda json: _extract_srv(json))))


def extract_txt_from_probe(probe: dict) -> list:
    grok = SubprocessDNSViz().grok(probe)
    return list(set(_search_in_grok(grok, lambda json: _extract_txt(json))))


def extract_status_from_probe(probe: dict) -> list[dict]:
    result = []
    grok = SubprocessDNSViz().grok(probe)
    for label, node in grok.items():
        status = node.get("status", None)
        delegation = node.get("delegation", None)
        delegation_status = None
        if delegation:
            delegation_status = delegation.get("status", None)

        result.append({
            "label": label,
            "zone_status": status,
            "delegation_status": delegation_status
        })
    return result

