"""
TLS utitity functions
"""

from dataclasses import dataclass
from xml.etree.ElementTree import fromstring as xml_fromstring
from typing import Optional
import logging

from ceti.api.tls import clienthello, sslscan, tr02102_2, tr03108_1
from ceti.utils.python import unique_id
from ceti.store import Mail
from public import public

from . import sslscan, tr02102_2, tr03108_1

logger = logging.getLogger(__name__)


@public
@dataclass
class TlsAnalysisResult:
    """
    The result of a TLS analysis.

    May be rendered in docbook as follows:

    .. code-block:: python

      {% import 'tls-lib.xml' as tls_funcs %}

      ...

      {{ tls_funcs.tls_section("(Sub-)Section Title", "Service Name", analysis_result) }}

    """

    #: The SslScanInvocation which was used to generate this TlsAnalysisResult. May also be a
    #: dummy SslScanInvocation in case this TlsAnalysisResult was generated from a TLS Client
    #: Hello Handshake Message. In this case, the invocation's port is set to -1, its cmd is []
    #: and invocation.host == invocation.ip.
    invocation: sslscan.SslScanInvocation
    #: Indicate whether the evaluated TLS implementation is conform to BSI TR-03108.
    is_conform: bool
    #: Scan results based on the TLS requirements defined in
    #: `BSI TR-03108-1 <https://www.bsi.bund.de/SharedDocs/Downloads/DE/BSI/Publikationen/TechnischeRichtlinien/TR03108/TR03108-1.pdf>`_.
    tr03108_1: list[tr03108_1.EvaluationResult]
    #: Scan results based on
    #: `BSI TR-02102-2 <https://www.bsi.bund.de/SharedDocs/Downloads/DE/BSI/Publikationen/TechnischeRichtlinien/TR02102/BSI-TR-02102-2.pdf>`_.
    tr02102_2: list[tr02102_2.EvaluationResult]
    #: Unique test id
    test_id: str
    #: Indicates if an has error occurred (no tls support, tcp connection failed, ...)
    is_error: bool
    #: Indicate if the TlsAnalysisResult was generated from a TLS Client Hello Handshake Message
    #: or is based on an sslscan.
    is_clienthello: bool
    # Stores the mail when is_clienthello
    mail: Optional[Mail] = None
    #: Stores an error message from scanssl when is_error
    error: Optional[str] = None


@public
def sslscan_version() -> str:
    scanner = sslscan.SubprocessSslScan("0.0.0.0", 0, "tls")
    return scanner.version()


@public
def tls_scan_host(
    host: str, port: str, proto: str = "tls"
) -> sslscan.SslScanInvocation:
    """
    Scan a host's service using sslscan.

    Args:
        host: A string containing the DNS resolveable name of the host
        port: A string containing the port where the service is listening
        proto: A string containing the protocol used (tls (default), startssl-smtp,
            startssl-imap or startssl-pop3)

    Returns:
        An SslScanInvocation containing all relevant information about the scan and its results.

    Raises:
        dns.exception.DNSException: Various exceptions that may occur when using dnspython
    """
    scanner = sslscan.SubprocessSslScan(host, str(port), proto)
    return scanner.run()


@public
def tls_analyze_invocation(invocation: sslscan.SslScanInvocation) -> TlsAnalysisResult:
    """
    Analyze a single SslScanInvocation
    """
    assert isinstance(invocation, sslscan.SslScanInvocation)
    result = invocation.result_as_xml()

    tr03108_result = tr03108_1.evaluate(result)
    tr02102_result = tr02102_2.evaluate(result)

    # check if there is an error in scanssl output
    # only one error is expected
    iserror = False
    error = None
    for err in result.findall("error"):
        iserror = True
        error = err.text

    # check if at least one TLS version is supported
    # (if not the service does not support TLS at all, plaintext port)
    for rslt in tr02102_result:
        if len(rslt.protos) == 0 and not iserror:
            iserror = True
            error = f"The host {invocation.ip} on port {invocation.port} did not appear to be an TLS service."

    return TlsAnalysisResult(
        test_id=unique_id(),
        is_clienthello=False,
        invocation=invocation,
        is_conform=(not iserror) and len(tr03108_result) > 0 and all(
            map(lambda res: res.compliant, tr03108_result)
        ),
        tr03108_1=tr03108_result,
        tr02102_2=tr02102_result,
        is_error=iserror,
        error=error,
    )


@public
def tls_analyze_clienthello(mail: Mail) -> TlsAnalysisResult:
    """
    Analyze a TLS ClientHello handshake message
    """
    assert isinstance(mail, Mail)

    hello = clienthello.ClientHello(mail.clienthello)
    result = hello.as_sslscan_xml()

    resultxml = xml_fromstring(result)
    tr03108_result = tr03108_1.evaluate(resultxml)
    tr02102_result = tr02102_2.evaluate(resultxml)

    iserror = sum(len(res.protos) for res in tr02102_result) == 0

    logger.debug('%s -> %s supports %d TLS versions.%s',
                 mail.sender, mail.recipient, sum(len(res.protos) for res in tr02102_result),
                 ' This service is classified as error' if iserror else '')


    return TlsAnalysisResult(
        test_id=unique_id(),
        is_error=iserror,
        is_clienthello=True,
        mail=mail,
        invocation=sslscan.SslScanInvocation(
            host=mail.clientip,
            ip=mail.clientip,
            port=mail.clientport,
            proto="ClientHello",
            cmd=[],
            result=result,
        ),
        is_conform=len(tr03108_result) > 0 and all(
            map(lambda res: res.compliant, tr03108_result)
        ),
        tr03108_1=tr03108_result,
        tr02102_2=tr02102_result,
    )
