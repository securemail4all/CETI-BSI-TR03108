"""
The sslscan module implements the actual scanning for TLS/SSL services. It is based on a slightly
patched sslscan executable. The results are given as XML which may be analyzed later.

Upon a scan execution the SubproccesSslScan.run() call returns an SslScanInvocation result that
includes all information about the invocation and its result.
"""

import logging
import subprocess
from dataclasses import dataclass
from subprocess import check_output
from xml.etree.ElementTree import Element
from xml.etree.ElementTree import fromstring as xml_fromstring

import dns.resolver
from ceti.utils.sanitize import remove_terminal_control

logger = logging.getLogger(__name__)


@dataclass
class SslScanInvocation:
    """
    The Result of an SubprocessSslScan.run() invocation.
    """

    #: The DNS resolvable name of the host that was scanned.
    #: This value was also used for SNI.
    host: str
    #: The IP address that was scanned.
    ip: str
    #: The tcp port that was scanned.
    port: str
    #: The protocol that was scanned (relevant for STARTTLS).
    proto: str
    #: A list containing the command used to execute sslscan.
    cmd: list[str]
    #: The output of the invocation.
    result: bytes

    def result_as_xml(self) -> Element:
        """
        Parse the invocation result as xml.

        Returns:
            An etree.Element representing the resulting XML document
        """
        return xml_fromstring(self.result)


class SubprocessSslScan:
    # pylint: disable=too-few-public-methods
    """
    Prepare an sslscan for a given service.

    Args:
        host: A string containing the DNS resolveable name of the host
        port: A string containing the port where the service is listening
        proto: A string containing the protocol used (tls, startssl-smtp,
            startssl-imap or startssl-pop3)
    """

    def __init__(self, host, port, proto, ip=None):
        self.host = host
        self.port = port
        self.proto = proto
        self.ip = ip
        self.cmd = None

    def version(self):
        cmdline = "sslscan --version"
        proc = subprocess.run(cmdline, capture_output=True, check=True, 
                              shell=True, timeout=60)
        stdout = proc.stdout.decode("utf-8")
        version = stdout.splitlines()[0]
        version = remove_terminal_control(version)
        return version.strip()
        

    def _get_ip(self):
        return dns.resolver.resolve(self.host, "A")[0].address

    def _ns(self, tag):
        XMLNS = "urn:uuid:6db3f5aa-a411-44be-afa2-a46d64a96127"
        return "{" + XMLNS + "}" + tag

    def _scan_cmd(self) -> list[str]:
        """
        Build the command used to execute sslscan

        Args:
            ip: The IP address of the host to scan
            sniname: The Serve Name Indication (SNI) name to send (usually the FQDN)
            port: The TCP port to scan
            starttls_proto: If starttls has to be used the starttls protocol that should
                be used (tls, startssl-smtp, startssl-imap or startssl-pop3)

        Returns:
            A list containing the command
        """
        arg = ""
        if self.proto.startswith("starttls-"):
            arg = "--" + self.proto
        # don't check for heartbleed to not disturb any firewall
        return [
            "sslscan",
            "--ipv4",
            # "--connect-timeout=30",
            "--no-heartbleed",
            "--show-sigs",
            "--show-certificate",
            "--xml=-",
            "--sni-name=" + self.host,
            arg,
            f"{self.ip}:{self.port}",
        ]

    def run(self) -> SslScanInvocation:
        """
        Perform the actual scan using the sslscan tool.
        Return an xml document containing the results.

        Returns:
            An :class:`SslScanInvocation` containing all relevant information about the scan
            and its results.
        """

        logger.info("starting tls scan of %s:%s", self.host, self.port)
        if not self.ip:
            self.ip = self._get_ip()
        self.cmd = self._scan_cmd()
        logger.debug("executing '%s'", self.cmd)
        result = check_output(self.cmd)
        logger.info("scan of host %s finished", self.host)

        return SslScanInvocation(
            host=self.host,
            ip=self.ip,
            port=self.port,
            proto=self.proto,
            cmd=self.cmd,
            result=result,
        )
