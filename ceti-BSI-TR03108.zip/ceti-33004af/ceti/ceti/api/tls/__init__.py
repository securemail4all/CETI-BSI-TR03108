"""Public API of TLS scanning and evaluation using sslscan

All of the TLS scanning and evaluation is based on the XML structure defined by the sslscan
tool.

The main use case of this module is to scan a server offering a TLS secured endpoint. Therefore
first, a scan has to be performed using the :class:`sslscan.SubprocessSslScan` class. The result
is given as :class:`sslscan.SslScanInvocation` which contains as well the parameters used to
execute `sslscan` as the result of the execution.

When a TLS implementation should be evaluated in the client role, this module is used to analyze
the TLS ClientHello Handshake Message. It contains all information used to evaluate the 
implemenation against BSI TR-02102-2.

The actual evaluation is done by the functions :func:`tr02102_2_evaluate` and
:func:`tr03108_1_evaluate` which iterate through the XML structure returned by sslscan. As this XML
structure usually is not available for TLS client evaluations,
:class:`cet.api.tls.clienthello.ClientHello` implements the conversion of a TLS ClientHello into an
XML structure that may be used for both evaluation functions.
"""


from .sslscan import SslScanInvocation
from .tls import TlsAnalysisResult, tls_scan_host, tls_analyze_invocation, tls_analyze_clienthello, sslscan_version

__all__ = [
    "SslScanInvocation",
    "TlsAnalysisResult",
    "tls_scan_host",
    "tls_analyze_invocation",
    "tls_analyze_clienthello",
    "sslscan_version"
]
