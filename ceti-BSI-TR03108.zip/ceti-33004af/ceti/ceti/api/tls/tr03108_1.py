"""
 The module evaluates the results of sslscan with the
 recommendations of TR 03108-1. For this purpose, the attribute
 "compliant" is added to relevant nodes.
"""

import logging
from dataclasses import dataclass


@dataclass
class EvaluationResult:
    tls_versions: list[str]
    supports_pfs: bool
    compliant: bool


logger = logging.getLogger(__name__)

XMLNS = (
    "https://www.bsi.bund.de/SharedDocs/Downloads"
    "/DE/BSI/Publikationen/TechnischeRichtlinien/TR03108/TR03108-1.pdf"
)


def _ns(element):
    return "{" + XMLNS + "}" + element


def _tls_versions(test):
    return [
        n.attrib["version"]
        for n in test.findall("protocol")
        if n.attrib["type"] == "tls" and n.attrib["enabled"] == "1"
    ]


def _supports_pfs(test):
    PFS_CIPHERS = {
        "TLSv1.2": [
            # Table 1 in TR 02102-2
            0xC023,
            0xC024,
            0xC02B,
            0xC02C,
            0xC0AC,
            0xC0AD,
            0xC027,
            0xC028,
            0xC02F,
            0xC030,
            0x0040,
            0x006A,
            0x00A2,
            0x00A3,
            0x0067,
            0x006B,
            0x009E,
            0x009F,
            0xC09E,
            0xC09F,
        ],
        "TLSv1.3": [
            # Table 11 in TR 02102-2
            0x1301, 
            0x1302, 
            0x1304], 
        # Actual TLS version used is not specified in clienthello
        # Test that there are no ciphers, groups or algos that are 
        # not recommended for one of TLS 1.2 or TLS 1.3
        "<fromclienthello>": [
            # Table 1 in TR 02102-2
            0xC023,
            0xC024,
            0xC02B,
            0xC02C,
            0xC0AC,
            0xC0AD,
            0xC027,
            0xC028,
            0xC02F,
            0xC030,
            0x0040,
            0x006A,
            0x00A2,
            0x00A3,
            0x0067,
            0x006B,
            0x009E,
            0x009F,
            0xC09E,
            0xC09F,
            # Table 11 in TR 02102-2
            0x1301, 
            0x1302, 
            0x1304
        ]
    }

    def check(t, v, c):
        return [
            n
            for n in t.findall("cipher")
            if n.attrib["sslversion"] == v
             and int(n.attrib["id"], 16) in c
        ]
        
    return any(map(lambda v: check(test, v, PFS_CIPHERS[v]), PFS_CIPHERS.keys()))


def evaluate(xml) -> list[EvaluationResult]:
    result = []
    for test in xml.findall("ssltest"):
        tls_versions = _tls_versions(test)
        supports_pfs = _supports_pfs(test)
        result.append(
            EvaluationResult(
                tls_versions=tls_versions,
                supports_pfs=supports_pfs,
                compliant=len(tls_versions) > 0 and supports_pfs,
            )
        )

    return result
