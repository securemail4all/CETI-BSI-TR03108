"""
Parse a TLS client hello in order to evaluate incoming tls connections as well.
"""

import binascii

from dataclasses import dataclass

from yattag import Doc, indent

from scapy.layers.tls.handshake import TLS13ClientHello
from scapy.layers.tls.all import TLS
from scapy.layers.tls.extensions import (
    TLS_Ext_SupportedVersion_CH,
    TLS_Ext_SignatureAlgorithms,
    TLS_Ext_SupportedGroups,
)
from scapy.layers.tls.crypto.groups import _tls_named_groups
from scapy.layers.tls.crypto.suites import _tls_cipher_suites
from scapy.layers.tls.keyexchange import _tls_hash_sig


def _tls_version_from_int(b):
    if b == 0x0304:
        return "TLSv1.3"
    if b == 0x0303:
        return "TLSv1.2"
    if b == 0x0302:
        return "TLSv1.1"
    if b == 0x0302:
        return "TLSv1.1"
    if b == 0x0301:
        return "TLSv1.0"
    if b == 0x0300:
        return "SSLv3"
    return None


def _group_name(identifier):
    if identifier in _tls_named_groups:
        return _tls_named_groups[identifier]
    return f"Unknown (0x{identifier:04x})"


def _cipher_name(identifier):
    if identifier in _tls_cipher_suites:
        return _tls_cipher_suites[identifier]
    return f"Unknown (0x{identifier:04x})"


def _sigalg_name(identifier):
    if identifier in _tls_hash_sig:
        return _tls_hash_sig[identifier]
    return f"Unknown (0x{identifier:04x})"

# The following values are reserved as GREASE values 
# for extensions, named groups, signature algorithms, and versions
# https://www.rfc-editor.org/rfc/rfc8701.html

GREASE = [
    0x0A0A,
    0x1A1A,
    0x2A2A,
    0x3A3A,
    0x4A4A,
    0x5A5A,
    0x6A6A,
    0x7A7A,
    0x8A8A,
    0x9A9A,
    0xAAAA,
    0xBABA,
    0xCACA,
    0xDADA,
    0xEAEA,
    0xFAFA,
]

class ClientHello:
    """
    A TLS Client Hello
    """

    def __init__(self, data: bytes):   
        self.raw_data = data

    def extensions(self):
        client_hello = TLS13ClientHello(self.raw_data[5:])
        return client_hello.ext

    def ciphers(self):
        result = []
        ciphers = TLS13ClientHello(self.raw_data[5:]).ciphers
        for cipher in ciphers:
            if cipher in GREASE:
                continue
            result.append(cipher)
        return result

    def tls_versions(self):
        result = []
        for ext in filter(
            lambda ext: isinstance(ext, TLS_Ext_SupportedVersion_CH),
            self.extensions(),
        ):
            for version in ext.versions:
                if version in GREASE:
                    continue
                text = _tls_version_from_int(version)
                if text:
                    result.append(text)
                else:
                    result.append(f"Unknown (0x{version:04x})")
        if len(result) == 0:
            result = [_tls_version_from_int(TLS13ClientHello(self.raw_data[5:]).fields['version'])]
        return result

    def sign_algos(self):
        result = []
        for ext in filter(
            lambda ext: isinstance(ext, TLS_Ext_SignatureAlgorithms), self.extensions()
        ):
            for sig_alg in ext.sig_algs:
                if sig_alg in GREASE:
                    continue
                result.append(sig_alg)
        return result

    def groups(self):
        result = []
        for ext in filter(
            lambda ext: isinstance(ext, TLS_Ext_SupportedGroups), self.extensions()
        ):
            for group in ext.groups:
                if group in GREASE:
                    continue
                result.append(group)
        return result

    def as_sslscan_xml(self):
        tls_versions = self.tls_versions()
        doc, tag, _text = Doc().tagtext()
        with tag("document", title="", version="", web=""):
            with tag("ssltest"):
                doc.stag("protocol", type="ssl", version="2", enabled="0")
                doc.stag(
                    "protocol",
                    type="ssl",
                    version="3",
                    enabled="1" if "SSLv3" in tls_versions else "0",
                )
                doc.stag(
                    "protocol",
                    type="tls",
                    version="1.0",
                    enabled="1" if "TLSv1.0" in tls_versions else "0",
                )
                doc.stag(
                    "protocol",
                    type="tls",
                    version="1.1",
                    enabled="1" if "TLSv1.1" in tls_versions else "0",
                )
                doc.stag(
                    "protocol",
                    type="tls",
                    version="1.2",
                    enabled="1" if "TLSv1.2" in tls_versions else "0",
                )
                doc.stag(
                    "protocol",
                    type="tls",
                    version="1.3",
                    enabled="1" if "TLSv1.3" in tls_versions else "0",
                )
                for c in self.ciphers():
                    doc.stag(
                        "cipher",
                        sslversion="<fromclienthello>",
                        cipher=_cipher_name(c),
                        id=f"0x{c:04x}",
                    )
                for g in self.groups():
                    doc.stag(
                        "group", sslversion="<fromclienthello>", name=_group_name(g), id=f"0x{g:04x}"
                    )
                for sg in self.sign_algos():
                    doc.stag(
                        "connection-signature-algorithm",
                        name=_sigalg_name(sg),
                        sslversion="<fromclienthello>",
                        id=f"0x{sg:04x}",
                    )
                # for e in self.extensions():
                #     with tag("extension", name=e.name):
                #         doc.cdata(repr(e))

        return indent(doc.getvalue(), indentation=" " * 4, newline="\r\n")
