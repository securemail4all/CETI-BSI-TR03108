"""
 The module evaluates the results of sslscan with the
 recommendations of TR 02102-2. For this purpose, the attributes
 "recommendation" and "compliant" are added to relevant nodes.

 recommendation is set to "use" if the guideline explicitly
 recommends the usage of the particular algorithm and is set to
 "do_not_use" if the guideline explicitly discourage the usage.
 If the guideline does not mention the algorithm, then the
 attribute "recommendation" is not set.

 The attribute "compliant" indicates whether the respective algorithm
 is compliant with the guideline. Therefore it is set to true or false
 The evaluation can be done in "strict" mode (default) or "non-strict"
 mode (see constructor) . In strict mode the usage of algorithmes are
 only considered compliant if the guideline explicitly recommends their
 usage (recommendation is set to "use"). In non-strict mode the usage
 of any algorithm is considered compliant unless the guideline explicitly
 discourage its usage. Furthermore the attribute "compliant" is added to
 the root node. Its value is true if and only if there is no node with
 compliant set to false.
 """

# The input can be generated with:
# 'sslscan --show-sigs --show-certificate --xml=- <HOST:PORT>'

import pkgutil
import logging

from itertools import product

from xml.etree.ElementTree import Element, fromstring as xml_fromstring

# from lxml.etree import Element

from dataclasses import dataclass
from typing import Union

from . import iana

logger = logging.getLogger(__name__)


@dataclass
class EvaluatedProperty:
    """
    An EvaluatedProperty represents a specific property of a TLS connection.
    As it is 'Evaluated', there is an attribute 'recommended' showing if it is recommended to
    support the given property.
    """

    name: str  #: The property's name
    recommended: bool  #: If the property is recommended
    identifier: int  #: The TLS internal identifier of the property

    def __hash__(self):
        return self.name.__hash__() ^ self.recommended.__hash__() ^ self.identifier.__hash__()


@dataclass
class EvaluationResult:
    #: Dictionary containing lists of EvaluatedCiphers grouped by the TLS version (dict's key)
    protos: list[
        EvaluatedProperty
    ]  #: A list containing all TLS/SSL versions identified on the server
    ciphers: dict[str, list[iana.Cipher]]
    groups: dict[str, list[iana.Group]]
    sign_algo: dict[str, list[Union[iana.SignatureAlgorithm, EvaluatedProperty]]]
    heartbleed: bool
    renegotiation: bool
    compression: bool
    compliant: bool
    bad_ciphers: list[iana.Cipher]
    bad_sign_algo: list[Union[iana.SignatureAlgorithm, EvaluatedProperty]]
    bad_groups: list[iana.Group]


RECOMMENDATIONS = {
    "TLSv1.2": {
        "ciphers": [
            # Table 1
            0xC023,
            0xC024,
            0xC02B,
            0xC02C,
            0xC0AC,
            0xC0AD,
            0xC027,
            0xC028,
            0xC02F,
            0xC030,
            0x0040,
            0x006A,
            0x00A2,
            0x00A3,
            0x0067,
            0x006B,
            0x009E,
            0x009F,
            0xC09E,
            0xC09F,
            # Table 2
            0xC025,
            0xC026,
            0xC02D,
            0xC02E,
            0xC029,
            0xC02A,
            0xC031,
            0xC032,
            0x003E,
            0x0068,
            0x00A4,
            0x00A5,
            0x003F,
            0x0069,
            0x00A0,
            0x00A1,
            # Table 3
            0xC037,
            0xC038,
            0xD001,
            0xD002,
            0xD005,
            0x00B2,
            0x00B3,
            0x00AA,
            0x00AB,
            0xC0A6,
            0xC0A7,
            0x00B6,
            0x00B7,
            0x00AC,
            0x00AD,
        ],
        "groups": [23, 24, 25, 26, 27, 28, 256, 257, 258],  # Table 4
        "sign_algo": [
            # Table 5 (signature) and table 6 (hash)
            0x0401,
            0x0402,
            0x0403,
            0x0501,
            0x0502,
            0x0503,
            0x0601,
            0x0602,
            0x0603,
            # Table 9 (actually they are related to TLS1.3,
            # but we accept them also for TLS1.2)
            0x0804,
            0x0805,
            0x0806,
            0x0809,
            0x080A,
            0x080B,
            0x0403,
            0x0503,
            0x0603,
            0x081A,
            0x081B,
            0x081C,
        ],
    },
    "TLSv1.3": {
        "ciphers": [0x1301, 0x1302, 0x1304],  # Table 11
        "groups": [23, 24, 25, 31, 32, 33, 256, 257, 258],  # Table 8
        "sign_algo": [
            # Table 9
            0x0804,
            0x0805,
            0x0806,
            0x0809,
            0x080A,
            0x080B,
            0x0403,
            0x0503,
            0x0603,
            0x081A,
            0x081B,
            0x081C,
        ],
        "sign_algo_cert": [
            # Table 10
            0x0402,
            0x0501,
            0x0601,
            0x0804,
            0x0805,
            0x0806,
            0x0809,
            0x080A,
            0x080B,
            0x0403,
            0x0503,
            0x0603,
            0x081A,
            0x081B,
            0x081C,
        ],
    },
    # Actual TLS version used is not specified in clienthello
    # Test that there are no ciphers, groups or algos that are 
    # not recommended for one of TLS 1.2 or TLS 1.3
    "<fromclienthello>": {
        "ciphers": [
            # Table 11
            0x1301, 
            0x1302, 
            0x1304,
            # Table 1
            0xC023,
            0xC024,
            0xC02B,
            0xC02C,
            0xC0AC,
            0xC0AD,
            0xC027,
            0xC028,
            0xC02F,
            0xC030,
            0x0040,
            0x006A,
            0x00A2,
            0x00A3,
            0x0067,
            0x006B,
            0x009E,
            0x009F,
            0xC09E,
            0xC09F,
            # Table 2
            0xC025,
            0xC026,
            0xC02D,
            0xC02E,
            0xC029,
            0xC02A,
            0xC031,
            0xC032,
            0x003E,
            0x0068,
            0x00A4,
            0x00A5,
            0x003F,
            0x0069,
            0x00A0,
            0x00A1,
            # Table 3
            0xC037,
            0xC038,
            0xD001,
            0xD002,
            0xD005,
            0x00B2,
            0x00B3,
            0x00AA,
            0x00AB,
            0xC0A6,
            0xC0A7,
            0x00B6,
            0x00B7,
            0x00AC,
            0x00AD,
            
            0x00FF, # TLS_EMPTY_RENEGOTIATION_INFO_SCSV (ignore flag)
            ],
     
        "groups": [
            # Table 8
            23, 24, 25, 31, 32, 33, 256, 257, 258,
            # Table 4
            23, 24, 25, 26, 27, 28, 256, 257, 258,
            ],  
        "sign_algo": [
            # Table 5 (signature) and table 6 (hash)
            0x0401,
            0x0402,
            0x0403,
            0x0501,
            0x0502,
            0x0503,
            0x0601,
            0x0602,
            0x0603,
            # Table 9 (actually they are related to TLS1.3,
            # but we accept them also for TLS1.2)
            # Table 9
            0x0804,
            0x0805,
            0x0806,
            0x0809,
            0x080A,
            0x080B,
            0x0403,
            0x0503,
            0x0603,
            0x081A,
            0x081B,
            0x081C,
            ],
        "sign_algo_cert": [
            # Table 10
            0x0402,
            0x0501,
            0x0601,
            0x0804,
            0x0805,
            0x0806,
            0x0809,
            0x080A,
            0x080B,
            0x0403,
            0x0503,
            0x0603,
            0x081A,
            0x081B,
            0x081C,
        ],
    },

    "keys": {"ecdsa": 250, "dss": 3000, "rsa": 3000},  # Table 12
}


def _evaluate_cipher(node: Element):
    """
    Evaluate a cipher suite supported by the TOE

        <cipher status="accepted" sslversion="TLSv1.3" bits="256" cipher="TLS_AES_256_GCM_SHA384" id="0x1302" strength="acceptable" curve="25519" ecdhebits="253" />

    Returns:
        A bool showing if the cipher suite is recommended.

    """
    tls_version = node.attrib["sslversion"]
    if tls_version in RECOMMENDATIONS:
        return EvaluatedProperty(
            identifier=int(node.attrib["id"], 16),
            name=node.attrib["cipher"],
            recommended=int(node.attrib["id"], 16)
            in RECOMMENDATIONS[tls_version]["ciphers"],
        )
    return EvaluatedProperty(
        identifier=int(node.attrib["id"], 16),
        name=node.attrib["cipher"],
        recommended=False,
    )


def _evaluate_property(prop: Element, recommendation_key: str) -> EvaluatedProperty:
    tls_version = prop.attrib["sslversion"]
    if tls_version in RECOMMENDATIONS:
        return EvaluatedProperty(
            name=prop.attrib["name"],
            recommended=int(prop.attrib["id"], 16)
            in RECOMMENDATIONS[tls_version][recommendation_key],
            identifier=int(prop.attrib["id"], 16),
        )
    return EvaluatedProperty(
        name=prop.attrib["name"],
        recommended=False,
        identifier=int(prop.attrib["id"], 16),
    )


def _evaluate_properties(
    props: list, recommendation_key: str
) -> list[EvaluatedProperty]:
    result = {}
    for prop in props:
        tls_version = prop.attrib["sslversion"]
        result.setdefault(tls_version, []).append(
            _evaluate_property(prop, recommendation_key)
        )
    return result


def _evaluate_doc(root):
    """
    Evaluate an ssltest result

    Returns:
        An EvaluationResult representing the result of the evaluation.
    """
    supported_protocols = []
    logger.debug("Evaluating supported TLS versions")
    for proto in root.findall("protocol"):
        if proto.attrib["enabled"] == "1":
            prototype = proto.attrib["type"]
            tlsversion = proto.attrib["version"]
            supported_protocols.append(
                EvaluatedProperty(
                    name=prototype.upper() + "v" + tlsversion,
                    recommended=tlsversion in ["1.2", "1.3"],
                    identifier=-1,
                )
            )

    logger.debug("Evaluating supported cipher suites")
    evaluated_ciphers = {}
    for cipher in root.findall("cipher"):
        tlsversion = cipher.attrib["sslversion"]
        evaluated_ciphers.setdefault(tlsversion, []).append(_evaluate_cipher(cipher))

    logger.debug("Evaluating supported signature algorithms")
    evaluated_groups = _evaluate_properties(root.findall("group"), "groups")
    evaluated_sign_algos = _evaluate_properties(
        root.findall("connection-signature-algorithm"), "sign_algo"
    )

    compression = False
    for node in root.findall("compression"):
        if node.attrib["supported"] == "1":
            compression = True

    renegotiation = False
    for node in root.findall("renegotiation"):
        if node.attrib["supported"] == "1" or node.attrib["secure"] == "1":
            renegotiation = True

    heartbleed = False
    for node in root.findall("heartbleed"):
        if node.attrib["vulnerable"] == "1":
            heartbleed = True

    logger.debug("Translating sslscan names to IANA names")
    iana_data = xml_fromstring(pkgutil.get_data(__name__, "tls-parameters.xml"))

    iana_ciphers = list(
        map(
            iana.Cipher.from_xmldefinition,
            iana_data.findall("{*}registry[@id='tls-parameters-4']/{*}record"),
        )
    )
    iana_groups = list(
        map(
            iana.Group.from_xmldefinition,
            iana_data.findall("{*}registry[@id='tls-parameters-8']/{*}record"),
        )
    )

    iana_sign_algos = list(
        filter(
            # don't add old tls12 algos, because they are added later
            lambda a: a.description!='Reserved for backward compatibility',
            map(
                iana.SignatureAlgorithm.from_xmldefinition_tls13,
                iana_data.findall("{*}registry[@id='tls-signaturescheme']/{*}record"),
            )
        )
    )

    iana_sign_algos += [
        iana.SignatureAlgorithm.from_xmldefinition_tls12(h, s)
            for h in iana_data.findall("{*}registry[@id='tls-parameters-18']/{*}record")
            for s in iana_data.findall("{*}registry[@id='tls-parameters-16']/{*}record")
    ]

    toe_ciphers = {}
    for tlsversion, ciphers in evaluated_ciphers.items():
        for cipher in ciphers:
            found = False
            for iana_definition in iana_ciphers:
                if cipher.identifier == iana_definition.identifier:
                    iana_definition.recommended = cipher.recommended
                    toe_ciphers.setdefault(tlsversion, []).append(iana_definition)
                    found = True
                    break
            if not found:
                logger.warning("Did not find iana definition for cipher %s", cipher)

    toe_groups = {}
    for tlsversion, groups in evaluated_groups.items():
        for group in groups:
            found = False
            for iana_definition in iana_groups:
                if group.identifier == iana_definition.identifier:
                    iana_definition.recommended = group.recommended
                    toe_groups.setdefault(tlsversion, []).append(iana_definition)
                    found = True
                    break
            if not found:
                logger.warning("Did not find iana definition for group %s", group)

    toe_sign_algos = {}
    for tlsversion, sign_algos in evaluated_sign_algos.items():
        for algo in sign_algos:
            found = False
            for iana_definition in iana_sign_algos:
                if algo.identifier == iana_definition.identifier:
                    iana_definition.recommended = algo.recommended
                    toe_sign_algos.setdefault(tlsversion, []).append(iana_definition)
                    found = True
                    break
            if not found:
                logger.warning(
                    "Did not find iana definition for signature algorithm %s", algo
                )
                toe_sign_algos.setdefault(tlsversion, []).append(algo)

    logger.debug("Performing final conformance tests")
    is_compliant = True
    for tlsversion, ciphers in toe_ciphers.items():
        for cipher in ciphers:
            if not cipher.recommended:
                is_compliant = False

    for tlsversion, groups in toe_groups.items():
        for group in groups:
            if not group.recommended:
                is_compliant = False

    for tlsversion, algos in toe_sign_algos.items():
        for algo in algos:
            if not algo.recommended:
                is_compliant = False

    for proto in supported_protocols:
        if not proto.recommended:
            is_compliant = False

    if compression or renegotiation or heartbleed:
        is_compliant = False

    bad_ciphers = []
    for _, ciphers in toe_ciphers.items():
        bad_ciphers.extend(
            filter(lambda c: not c.recommended and not c in bad_ciphers, ciphers)
        )

    bad_sign_algo = []
    for _, algos in toe_sign_algos.items():
        bad_sign_algo.extend(
            filter(lambda a: not a.recommended and not a in bad_sign_algo, algos)
        )

    bad_groups = []
    for _, groups in toe_groups.items():
        bad_groups.extend(
            filter(lambda g: not g.recommended and not g in bad_groups, groups)
        )

    return EvaluationResult(
        ciphers=toe_ciphers,
        groups=toe_groups,
        sign_algo=toe_sign_algos,
        protos=supported_protocols,
        compression=compression,
        renegotiation=renegotiation,
        heartbleed=heartbleed,
        compliant=is_compliant,
        bad_ciphers=list(bad_ciphers),
        bad_sign_algo=list(bad_sign_algo),
        bad_groups=list(bad_groups),
    )


def evaluate(xml) -> list[EvaluationResult]:
    results = []
    for test in xml.findall("ssltest"):
        results.append(_evaluate_doc(test))
    return results
