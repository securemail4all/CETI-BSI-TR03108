"""
IANA definitions for TLS.
"""
import re
from dataclasses import dataclass
from typing import Optional
from xml.etree.ElementTree import Element

@dataclass
class Cipher:
    description: str
    rfc: Optional[str]
    identifier: Optional[int]
    recommended: bool = False

    @staticmethod
    def from_xmldefinition(xmldefinition: Element):
        cipher_id = next(
            map(
                lambda node: Cipher._convert_iana_cipher_id(node.text),
                xmldefinition.findall("{*}value"),
            ),
            None,
        )
        description = xmldefinition.find("{*}description").text
        rfc_node = xmldefinition.find("{*}xref[@type='rfc']")
        rfc = (
            rfc_node.attrib["data"]
            if rfc_node is not None and "data" in rfc_node.attrib
            else None
        )
        return Cipher(
            description=description, rfc=rfc, identifier=cipher_id
        )

    @staticmethod
    def _convert_iana_cipher_id(aid):
        if not re.match(r"^0x[0-9A-Fa-f]+,0x[0-9A-Fa-f]+$", aid):
            return None
        l = list(map(lambda x: int(x, 16), aid.split(",")))
        return l[0] * 256 + l[1]

    def __hash__(self):
        return self.identifier.__hash__()


@dataclass
class Group:
    description: str
    rfc: Optional[str]
    identifier: Optional[int]
    recommended: bool = False

    @staticmethod
    def from_xmldefinition(xmldefinition: Element):
        group_id = next(
            map(
                lambda node: Group._try_to_int(node.text),
                xmldefinition.findall("{*}value"),
            ),
            None,
        )
        description = xmldefinition.find("{*}description").text
        rfc_node = xmldefinition.find("{*}xref[@type='rfc']")
        rfc = (
            rfc_node.attrib["data"]
            if rfc_node is not None and "data" in rfc_node.attrib
            else None
        )
        return Group(
            description=description, rfc=rfc, identifier=group_id
        )


    @staticmethod
    def _try_to_int(x):
        try:
            return int(x)
        except ValueError:
            return None


@dataclass
class SignatureAlgorithm:
    description: str
    rfc: Optional[str]
    identifier: Optional[int]
    recommended: bool = False

    @staticmethod
    def _parse_xml(xmldefinition: Element):
        alg_id = next(
            map(
                lambda node: SignatureAlgorithm._try_to_int(node.text),
                xmldefinition.findall("{*}value"),
            ),
            None,
        )
        description = xmldefinition.find("{*}description").text
        rfc_node = xmldefinition.find("{*}xref[@type='rfc']")
        rfc = (
            rfc_node.attrib["data"]
            if rfc_node is not None and "data" in rfc_node.attrib
            else None
        )
        return {
            "description": description,
            "rfc": rfc,
            "identifier": alg_id
        }

    @staticmethod
    def from_xmldefinition_tls13(xmldefinition: Element):
        return SignatureAlgorithm(**SignatureAlgorithm._parse_xml(xmldefinition))

    @staticmethod
    def from_xmldefinition_tls12(xmlhash: Element, xmlsignalgo: Element):
        # We are mapping the tls12 signalgo+hash-combination to an tls13 signature scheme
        hash=SignatureAlgorithm._parse_xml(xmlhash)
        signalgo=SignatureAlgorithm._parse_xml(xmlsignalgo)
        return SignatureAlgorithm(
            description = signalgo["description"]+"+"+hash["description"],
            rfc =
                signalgo["rfc"]+"/"+hash["rfc"]
                if signalgo["rfc"] != hash["rfc"]
                else hash["rfc"],
            identifier =
                (hash["identifier"]<<8)+signalgo["identifier"]
                if hash["identifier"] is not None and signalgo["identifier"] is not None
                else None
        )

    @staticmethod
    def _try_to_int(x):
        try:
            return int(x, 16)
        except ValueError:
            return None
