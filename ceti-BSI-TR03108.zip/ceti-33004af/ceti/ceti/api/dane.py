import os
import subprocess
import tempfile
import logging
import json
from shlex import quote
from os.path import join

from public import public

logger = logging.getLogger(__name__)


@public
def gnutls_version() -> str:
    """Returns the software version of gnutls.

    Returns:
        str: version of gnutls
    """
    return SubprocessGnuTLS().version()


@public
def dane_version() -> str:
    """Returns the software version of dane-check.

    Returns:
        str: version of dane-check
    """
    return SubprocessDaneCheck().version()


@public
def dane_tlsa_is_compliant(tlsa_records: list) -> bool:
    """Checks if the given tlsa records are compliant with BSI TR-03108-1.

    In order to comply with BSI TR-03108-1, at least one hash 
    of the TLSA record must match the hash of the X509 certificate 
    of the service being tested.

    Args:
        tlsa_records (list): list of tlsa records as returned by ``dane_receive_tlsa_records``

    Returns:
        bool: true if compliant else false
    """
    assert isinstance(tlsa_records, list)

    ret = False
    for record in tlsa_records:
        if record["result"]["verification"]:
            ret = True
    return ret


@public
def dane_receive_tlsa_records(host: str, port: int) -> list[dict]:
    """Verifies that tlsa records match the X.509 certificate of a given starttls-stmp server.

    Retrieves the X.509 certificate from the specified host:port
    using starttls-stmp. It then queries the tlsa records
    using DNSSec and checks that the X.509 certificate matches
    the tlsa records.

    Args:
        host(str): hostname of the starttls-stmp server
        port(int): tcp port of the starttls-stmp server

    Returns:
        list[dict]: list of verifed tlsa records
    """
    assert isinstance(host, str)
    assert len(host) > 0

    assert isinstance(port, int)
    assert port >= 0 and port < 65536

    dane = SubprocessDaneCheck()
    gnutls = SubprocessGnuTLS()
    cert_file = gnutls.save_cert_starttls_smtp(host, port)
    cert_text = gnutls.pem_pretty_print(cert_file)
    ret = dane.dane_check(host, port, cert_file)
    
    for tsla in ret:
        tsla["certificate"] = cert_text 
    return ret


class SubprocessDaneCheck():

    def __init__(self):
        self.cwd = tempfile.TemporaryDirectory()

    def _exec(self, cmdline):
        logger.debug("Execute %s" % cmdline)
        proc = subprocess.run(cmdline, cwd=self.cwd.name,
                              capture_output=True, check=True, shell=True, timeout=60)
        stdout = proc.stdout.decode("utf-8")
        return stdout

    def version(self):
        return self._exec("dane-check --version")

    def dane_check(self, host, port, certfile):
        port = str(port)

        if certfile is None:
            ret = [{"result": {
                "verification": False,
                "info": f"Failed to download X.509 certificate from {host}:{port}"
            }}]
            return ret

        try:
            stdout = self._exec("dane-check {} {} {}".format(
                quote(host), quote(port), quote(certfile)
            ))
            ret = json.loads(stdout)["tlsaResourceRecords"]
        except subprocess.CalledProcessError as exception:
            stdout = exception.stdout
            ret = [{"result": {
                "verification": False,
                "info": json.loads(stdout)["error"]
            }}]
        except subprocess.TimeoutExpired as exception:
            ret = [{"result": {
                "verification": False,
                "info": f"dane-check timed out for {host}:{port}"
            }}]

        return ret


class SubprocessGnuTLS():

    def __init__(self):
        self.cwd = tempfile.TemporaryDirectory()

    def _exec(self, cmdline, stdin=None):
        logger.debug("Execute %s" % cmdline)

        proc = subprocess.run(cmdline, cwd=self.cwd.name,
                              capture_output=True, check=True, 
                              shell=True, input=stdin, timeout=60)
        stdout = proc.stdout.decode("utf-8")
        return stdout

    def version(self):
        cmd = "gnutls-cli --version"
        ret = self._exec(cmd)
        version = ret.splitlines()[0]
        return version

    def save_cert_starttls_smtp(self, host, port):

        port = str(port)
        cert_file = "cert-{}.pem".format(quote(host))

        gnutls_cli_args = " --no-ca-verification"
        gnutls_cli_args += " --save-cert {}".format(quote(cert_file))
        gnutls_cli_args += " --starttls-proto smtp"
        gnutls_cli_args += " --port {}".format(quote(port))
        cmd = "echo -n quit | gnutls-cli {} {}".format(
            gnutls_cli_args, quote(host))

        try:
            self._exec(cmd)
            return join(self.cwd.name, cert_file)
        except subprocess.CalledProcessError as exception:
            return None
        except subprocess.TimeoutExpired as exception:
            return None
    
    def pem_pretty_print(self, certfile):

        cmd = "certtool -i"

        try:
            with open(certfile, "rb") as f:
                cert = f.read()
                pretty = self._exec(cmd, stdin=cert)
                return pretty
        except Exception as exception:
            return ""