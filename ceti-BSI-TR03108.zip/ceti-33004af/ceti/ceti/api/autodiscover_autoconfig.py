"""
Helper methods for Autoconfig/Discover
"""

import logging
import xml.etree.ElementTree as ET
import requests

from ceti.api import dnsviz_probe_rdtype
from ceti.api import dnsviz_srv
# from ceti.api import dnssec_analyze
from ceti.api import dnsviz_status

logger = logging.getLogger(__name__)

def is_valid_domain(domain):
    probe = dnsviz_probe_rdtype(domain, "SRV")
    ret = dnsviz_status(probe)
    if ret == "NOERROR":
        return True
    else:
        return False

def get_srv_entries(domain, suffix="_autodiscover"):
    probe = dnsviz_probe_rdtype(f"{suffix}._tcp.{domain}", "SRV")
    srv_entries = dnsviz_srv(probe)
    #dnssec_result = dnssec_analyze(probe)
    #return dnssec_result, srv_entries
    return srv_entries

def get_response(url):
    logger.debug("HTTP get request for URL: %s" % url)
    try:
        res = requests.get(url, timeout=120)
        return res.content
    except:
        return b''

def split_url_port(url_port_list):
    result = []
    if url_port_list:
        for u_p in url_port_list:
            result.append((u_p.split(":")[0], str(u_p.split(":")[1])))
    return result

def parse_autoconfig(data):
    valid_xml = False
    parsed_protocol = []
    if data == b'':
        return False, parsed_protocol

    try:
        root = ET.fromstring(data)
        if root.tag == "clientConfig" and root.attrib["version"] and root.attrib["version"] == "1.1":
            for i in range(len(root[0])):
                if root[0][i].tag in ["incomingServer", "outgoingServer"]:
                    protocol_name = str(root[0][i].attrib["type"]).upper()
                    direction = str(root[0][i].tag).replace("Server", "")
                    hostname = ""
                    port = ""
                    ssl = False
                    starttls = False
                    for j in range(len(root[0][i])):
                        if root[0][i][j].tag == "hostname":
                            hostname = root[0][i][j].text
                        if root[0][i][j].tag == "port":
                            port = root[0][i][j].text
                        if root[0][i][j].tag == "socketType" and (root[0][i][j].text == "SSL" or root[0][i][j].text == "TLS"):
                            ssl = True
                        if root[0][i][j].tag == "socketType" and root[0][i][j].text == "STARTTLS":
                            starttls = True
                            
                    p_data = {
                              "protocol_name": protocol_name,
                              "direction": direction,
                              "hostname": hostname,
                              "port": port,
                              "SSL": ssl,
                              "STARTTLS": starttls
                             }
                    parsed_protocol.append(p_data)

            valid_xml = True
    except:
        return False, parsed_protocol

    return valid_xml, parsed_protocol

def parse_autodiscover(data):
    valid_xml = False
    parsed_protocol = []
    if data == b'':
        return False, parsed_protocol

    try:
        root = ET.fromstring(data)
        if root.tag.split("}")[-1] == "Autodiscover":
            for i in range(len(root[0])):
                for j in range(len(root[0][i])):
                    if root[0][i][j].tag.split("}")[-1] == "Protocol":
                        protocol_name = ""
                        hostname = ""
                        port = ""
                        SSL = False
                        for k in range(len(root[0][i][j])):
                            if root[0][i][j][k].tag.split("}")[-1] == "Type":
                                protocol_name = str(root[0][i][j][k].text)
                            if root[0][i][j][k].tag.split("}")[-1] == "Server":
                                hostname = str(root[0][i][j][k].text)
                            if root[0][i][j][k].tag.split("}")[-1] == "Port":
                                port = str(root[0][i][j][k].text)
                            if root[0][i][j][k].tag.split("}")[-1] == "SSL" and root[0][i][j][k].text == "on":
                                SSL = True

                        p_data = {
                          "protocol_name": protocol_name,
                          "hostname": hostname,
                          "port": port,
                          "SSL": SSL,
                          "STARTTLS": False
                        }
                        parsed_protocol.append(p_data)

            valid_xml = True
    except:
        return False, parsed_protocol

    return valid_xml, parsed_protocol
