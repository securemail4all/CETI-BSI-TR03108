"""
Public API of internal CETI scan end analysis functionality

TLS
***

A common TLS analysis should be done like this:

    1. Include a :class:`tls.SslScanInvocation` in your `ScanResult`-Type and initialize it in your
    :func:`analyze()` function as follows:

       .. code-block:: python
    
            def scan(self):
                tls_scan_result = tls_scan_host(hostname, port)
                return MyScanResult(
                    # ...
                    tls=tls_scan_result,
                )

    2. Include a :class:`tls.TlsAnalysisResult` in your `AnalysisResult`-Type and
    initialize it in your :func:`analyze()` function as follows:

       .. code-block:: python
    
            def analyze(self):
                return MyAnalyzeResult(
                    # ...
                    tls=tls_analyze_invocation(tls_scan_result),
                )

    3. Include the TLS result in your report:

       .. code-block:: python
       
           {% import 'tls-lib.xml' as tls_funcs %}
       
           ...
       
           {{ tls_funcs.tls_section("(Sub-)Section Title", "Service Name", tls) }}

    4. For conformance tests, you may use the property :code:`TlsAnalysisResult.is_conform` in your
       code.

API functions
^^^^^^^^^^^^^
"""

from public import public

from ceti.api.dane import *

from ceti.api.dnsviz import *

from ceti.api.tls import *

from ceti.api.tlsrpt import *

for apifunc in dir():
    if not apifunc.startswith("_") and hasattr(apifunc, "__module__"):
        public(locals()[apifunc])

# __all__ = [
#     "dane_receive_tlsa_records",
#     "dane_version",
#     "dane_tlsa_is_compliant",
#     "tlsrpt_validate_dnsrecord",
#     "tlsrpt_extract_report",
#     "tlsrpt_validate_report",
#     "dnsviz_probe_rdtype",
#     "dnsviz_version",
#     "dnsviz_mx",
#     "dnsviz_srv",
#     "dnsviz_txt",
#     "dnsviz_issues",
#     "dnsviz_status",
#     "dnsviz_is_compliant",
#     "dnssec_analyze",
#     "tls_scan_host",
#     "tls_analyze_invocation",
#     "tls_analyze_clienthello",
# ]
