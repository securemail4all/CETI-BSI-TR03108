"""
This module defines dataclasses that are used across multiple scanners and the API.
It is encouraged to no directly return them in a :code:`scan()` or :code:`analyze()` function
as it may not be clear to which scanner the data belongs. Wrap them in a scanner specific type
instead:

.. code-block:: python

    @dataclass
    class MyScannerScanResult:
         dnssec: DnsVizProbeScanResult
         # ...

    @dataclass
    class MyScannerAnalyzeResult:
         dnssec: DNSSecResult
         # ...

"""

from collections.abc import Mapping
from dataclasses import dataclass
import re

@dataclass
class MtaStsPolicy:
    """
    MTA-STS policy content as defined in
    `RFC 8461 <https://datatracker.ietf.org/doc/html/rfc8461.html>`_, section 3.2.
    """
    #: One of "enforce", "testing", or "none", indicating the
    #: expected behavior of a Sending MTA in the case of a policy
    #: validation failure. See
    #: `RFC 8461 <https://datatracker.ietf.org/doc/html/rfc8461.html>`_ Section 5,
    #: "Policy Application", for more details about the three modes.
    mode: str
    #: Allowed MX patterns.  One or more patterns matching allowed
    #: MX hosts for the Policy Domain.  As an example,
    #:
    #: .. code-block:: python
    #:
    #:     mx: mail.example.com <CRLF>
    #:     mx: *.example.net
    #:
    #: ..
    #:
    #: indicates that mail for this domain might be handled by MX
    #: "mail.example.com" or any MX at "example.net".  Valid patterns can be
    #: either fully specified names ("example.com") or suffixes prefixed by
    #: a wildcard ("*.example.net").  If a policy specifies more than one
    #: MX, each MX MUST have its own "mx:" key, and each MX key/value pair
    #: MUST be on its own line in the policy file.  In the case of
    #: Internationalized Domain Names [RFC5891], the "mx" value MUST specify
    #: the Punycode-encoded A-label [RFC3492] to match against, and not the
    #: Unicode-encoded U-label.  The full semantics of certificate
    #: validation (including the use of wildcard patterns) are described in
    #: `RFC 8461 <https://datatracker.ietf.org/doc/html/rfc8461.html>`_ Section 4.1,
    #: "MX Host Validation".
    mx: list[str]
    #: Max lifetime of the policy (plaintext non-negative
    #: integer seconds, maximum value of 31557600).  Well-behaved clients
    #: SHOULD cache a policy for up to this value from the last policy
    #: fetch time.  To mitigate the risks of attacks at policy refresh
    #: time, it is expected that this value typically be in the range of
    #: weeks or greater.
    max_age: int



@dataclass
class DnsVizProbeScanResult:
    domain: str
    rdtype: str
    dnsviz_version: str
    result: dict

@dataclass
class DNSSecResult:
    probe: DnsVizProbeScanResult
    domain: str
    rdtype: str
    issues: list
    status: str
    graph: bytes
    compliant: bool
    dnsviz_version: str

_FIELDS_RE = re.compile("\\s*(\\w+)=([^\\s;]+)\\s*")
_TXT_REGEX = re.compile(r'"((?:\\.|[^"\\])+)"')

@dataclass
class TxtRecord(Mapping):
    """
    Dataclass simplifying the access to a DNS TXT Resource Record.
    Implements :class:`collections.abc.Mapping` to allow accessing the key-value pairs defined
    in the Resource Record directly.
    """
    #: The TXT Resource Record's text value without " symbols.
    text: str
    #: The dns query used to resolve this Resource Record
    query: str

    def __post_init__(self):
        self.parsed = {}
        self._parse()

    def _parse(self):
        if not isinstance(self.text, str):
            return
        txt = "".join(_TXT_REGEX.findall(self.text))
        for key, value in _FIELDS_RE.findall(txt):
            self.parsed[key] = value

    def __iter__(self):
        return self.parsed.__iter__()

    def __getitem__(self, k):
        return self.parsed.__getitem__(k)

    def __len__(self):
        return self.parsed.__len__()

    def __str__(self):
        return self.text

