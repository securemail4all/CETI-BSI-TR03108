"""
Docbook writer building BSI styled documents using dbt.
"""

import logging
import subprocess
import os
from os.path import join

from .docbook import DocbookWriter

logger = logging.getLogger(__name__)

class DbtWriter(DocbookWriter):
    def build(self):
        outdir = join(self._get_buildpath(), "out")
        os.makedirs(outdir, exist_ok=True)
        target = join(outdir, "report.pdf")

        cmdline = ["touch", target]
        logger.debug("Execute %s", cmdline)
        _proc = subprocess.run(
            cmdline,
            cwd=self._get_buildpath(),
            check=True,
            shell=False,
            timeout=600,
        )
