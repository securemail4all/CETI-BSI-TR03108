from os.path import join


class BaseReport:

    def __init__(self):
        self.format = "BaseFormat"
        self.path = None
        self.index_file = None

    def get_index_file_path(self):
        if None in [self.path, self.index_file]:
            raise Exception("Report not yet stored. Index file not available.")
        return join(self.path, self.index_file)

    def store(self, path):
        self.path = path
        self.index_file = join(path, "BaseFile")

