"""
Docbook writer

This writer implements a report writer based on the BSI docbook toolchain (DBT).
"""

from abc import ABC, abstractmethod
import datetime
import json
import logging
import os
import subprocess
import tempfile
from collections import OrderedDict
from collections.abc import Mapping
from dataclasses import asdict, dataclass, field
from itertools import chain
from os.path import join
from typing import Callable, Optional

from jinja2 import Environment as JinjaEnvironment
from jinja2 import PackageLoader, StrictUndefined, select_autoescape


from ceti.api import dane_version, dnsviz_version, gnutls_version, sslscan_version
from ceti.api.tls import TlsAnalysisResult
from ceti.scanner import autodiscover_autoconfig, dane, mtasts, tlsrpt
from ceti.scanner.tls import (
    OpportunisticFallBackAnalyzeResult,
    TlsMailAnalyzeResult,
    TlsMTAAnalyzeResult,
    TlsServicesAnalyzeResult,
)
from ceti.utils.python import FilterableList, flatten_list
from ceti.utils.tmpfs import TmpFileStore
from ceti.config import target_as_yaml
from ceti.environment import Environment
from ceti.utils.sanitize import clean_path
from ceti.writer.base import BaseWriter
from ceti.writer.report import BaseReport


logger = logging.getLogger(__name__)


@dataclass
class Requirement:
    name: str
    compliant: Callable[[FilterableList], bool]
    sections: list[str]
    mandatory: bool


@dataclass
class DocumentModule:
    # pylint: disable=too-many-instance-attributes
    title: str
    compliance: list[Requirement] = field(default_factory=list)
    data: Callable[[Environment, FilterableList], Mapping] = field(
        default_factory=lambda: lambda env, _x: {}
    )
    chapter: Optional[str] = None
    methods: Optional[list[str]] = None
    appendix: Optional[str] = None


class DocbookReport(BaseReport):
    def __init__(self, index_file, data):
        super().__init__()
        self.format = "pdf"
        self.data = data
        self.index_file = index_file

    def store(self, path):
        self.path = path

        os.makedirs(path, exist_ok=True)
        with open(join(path, self.index_file), "wb") as f:
            f.write(self.data)


class StaticTemporaryDirectory:
    def __init__(self, tmpdir):
        os.makedirs(tmpdir, exist_ok=True)
        self.name = tmpdir


class DocbookWriter(ABC, BaseWriter):
    def __init__(self, environment):
        super().__init__(environment)

        if environment.ceti_config.debug:
            # use static dir for temporary DBT output and keep the files
            self.cwd = StaticTemporaryDirectory("/tmp/dbt/")
        else:
            # delete temporary DBT output dir automatically
            self.cwd = tempfile.TemporaryDirectory()

        self.modules = OrderedDict()

        ##
        # TLS
        ##
        self.modules["E&F"] = DocumentModule(
            data=lambda env, results: {
                "ceti": env.ceti_config,
                "mail_results": results.filter(TlsMailAnalyzeResult),
                "service_results": results.filter(TlsServicesAnalyzeResult),
                "mta_results": results.filter(TlsMTAAnalyzeResult),
                "fallback_results": results.filter(OpportunisticFallBackAnalyzeResult),
            },
            methods=["tls-method.xml"],
            title="Transport Layer Security (TLS)",
            chapter="tls-chapter.xml",
            appendix="tls-appendix.xml",
            compliance=[
                Requirement(
                    name="TR-03108-01-M: MUA to MHS Communication",
                    compliant=lambda results: results.contains(TlsServicesAnalyzeResult)
                    and results.contains(
                        autodiscover_autoconfig.AutodiscoverAutoconfigAnalyzeResult
                    )
                    and all(
                        chain(
                            map(
                                lambda res: res.tls_analysis.is_conform,
                                results.filter(TlsServicesAnalyzeResult),
                            ),
                            map(
                                lambda res: res.compliant,
                                results.filter(
                                    autodiscover_autoconfig.AutodiscoverAutoconfigAnalyzeResult
                                ),
                            ),
                        )
                    ),
                    sections=[
                        "sec.tls.services",
                        "sec.autodiscover",
                        "sec.autoconfig",
                        "sec.srvrecords",
                    ],
                    mandatory=True,
                ),
                Requirement(
                    name="TR-03108-02-R: MUA to MHS Communication Backwards Compatibility",
                    compliant=lambda results: results.contains(
                        OpportunisticFallBackAnalyzeResult
                    )
                    and all(
                        map(
                            lambda res: res.is_compliant,
                            results.filter(OpportunisticFallBackAnalyzeResult),
                        ),
                    ),
                    sections=["sec.tls.fallback"],
                    mandatory=False,
                ),
                Requirement(
                    name="TR-03108-03-M: MTA to MTA Inbound Transport Encryption",
                    compliant=lambda results: results.contains(TlsMTAAnalyzeResult)
                    and all(
                        map(
                            lambda res: res.tls_analysis.is_conform,
                            results.filter(TlsMTAAnalyzeResult),
                        )
                    ),
                    sections=["sec.tls.mta2mta-inbound"],
                    mandatory=True,
                ),
                Requirement(
                    name="TR-03108-04-M: MTA to MTA Outbound Transport Encryption",
                    compliant=lambda results: results.contains(TlsMailAnalyzeResult)
                    and all(
                        map(
                            lambda res: res.tls_analysis.is_conform,
                            results.filter(TlsMailAnalyzeResult),
                        )
                    ),
                    sections=["sec.tls.mta2mta-outbound"],
                    mandatory=True,
                ),
            ],
        )

        ##
        # AutodiscoverAutoConfig
        ##
        def autodiscover_autoconfig_data(env, results):
            result = results.first(
                autodiscover_autoconfig.AutodiscoverAutoconfigAnalyzeResult
            )
            return {
                "ceti": env.ceti_config,
                "result": result if result else None,
            }

        self.modules["E&F2"] = DocumentModule(
            title="AutodiscoverAutoconfig",
            methods=["autodiscover-autoconfig-methods.xml"],
            chapter="autodiscover-autoconfig-chapter.xml",
            appendix="autodiscover-autoconfig-appendix.xml",
            data=autodiscover_autoconfig_data,
        )

        ##
        # DANE
        ##
        self.modules["C&D"] = DocumentModule(
            title="Outbound DNS-based Authentication of Named Entities (DANE)",
            chapter="dane-chapter.xml",
            appendix="dane-appendix.xml",
            methods=["dane-inbound-methods.xml", "dane-outbound-methods.xml"],
            data=lambda env, results: {
                "ceti": env.ceti_config,
                "start_time": env.test_config.start_time,
                "end_time": env.test_config.start_time,
                "results_cxx": results.filter(dane.TR03108_C_XX_Result),
                "results_d01": results.filter(dane.TR03108_D_01_Result),
                "results_d02": results.filter(dane.TR03108_D_02_Result),
                "tmpfs": TmpFileStore(),
            },
            compliance=[
                Requirement(
                    name="TR-03108-05-M: Inbound DANE Transport Encryption",
                    compliant=lambda results: results.contains(dane.TR03108_D_01_Result)
                    and results.contains(dane.TR03108_D_02_Result)
                    and all(
                        chain(
                            map(
                                lambda res: res.compliant,
                                results.filter(dane.TR03108_D_01_Result),
                            ),
                            map(
                                lambda res: res.compliant,
                                results.filter(dane.TR03108_D_02_Result),
                            ),
                        )
                    ),
                    sections=["sec.dane.inbound"],
                    mandatory=True,
                ),
                Requirement(
                    name="TR-03108-06-M: Outbound DANE Transport Encryption",
                    compliant=lambda results: results.contains(dane.TR03108_C_XX_Result)
                    and all(
                        map(
                            lambda res: res.compliant,
                            results.filter(dane.TR03108_C_XX_Result),
                        )
                    ),
                    sections=["sec.dane.outbound"],
                    mandatory=True,
                ),
            ],
        )

        ##
        # MTA-STS
        ##
        self.modules["I&J"] = DocumentModule(
            title="MTA-STS",
            methods=["mtasts-inbound-methods.xml", "mtasts-outbound-methods.xml"],
            chapter="mtasts-chapter.xml",
            appendix="mtasts-appendix.xml",
            data=lambda _, results: {
                "results": [
                    asdict(result)
                    for result in results.filter(mtasts.MtaStsAnalyzeResult)
                ]
            },
            compliance=[
                Requirement(
                    name="TR-03108-07-R: Inbound MTA-STS Transport Encryption",
                    compliant=lambda results: results.contains(
                        mtasts.MtaStsAnalyzeResult
                    )
                    and all(
                        map(
                            lambda res: res.module_i.compliant,
                            results.filter(mtasts.MtaStsAnalyzeResult),
                        )
                    ),
                    sections=["sec.mtasts.inbound"],
                    mandatory=False,
                ),
                Requirement(
                    name="TR-03108-08-R: Outbound MTA-STS Transport Encryption",
                    compliant=lambda results: results.contains(
                        mtasts.MtaStsAnalyzeResult
                    )
                    and all(
                        map(
                            lambda res: res.module_j.compliant,
                            results.filter(mtasts.MtaStsAnalyzeResult),
                        )
                    ),
                    sections=["sec.mtasts.outbound"],
                    mandatory=False,
                ),
            ],
        )

        ##
        # TLSRPT
        ##
        def tlsrpt_data(env, results):
            data = results.first(tlsrpt.TlsRptAnalysisResult)
            return {
                "ceti": env.ceti_config,
                "result": asdict(data) if data else None,
                "tmpfs": TmpFileStore(),
                "json": json,
            }

        self.modules["G&H"] = DocumentModule(
            title="TLSRPT",
            methods=["tlsrpt-outbound-methods.xml", "tlsrpt-inbound-methods.xml"],
            chapter="tlsrpt-chapter.xml",
            appendix="tlsrpt-appendix.xml",
            data=tlsrpt_data,
            compliance=[
                Requirement(
                    name="TR-03108-09-M: Sending TLSRPT Reports",
                    compliant=lambda results: results.contains(
                        tlsrpt.TlsRptAnalysisResult
                    )
                    and all(
                        map(
                            lambda res: res.req_09_compliant,
                            results.filter(tlsrpt.TlsRptAnalysisResult),
                        )
                    ),
                    sections=["sec.tlsrpt.outbound"],
                    mandatory=True,
                ),
                Requirement(
                    name="TR-03108-10-M: Receiving TLSRPT Reports",
                    compliant=lambda results: results.contains(
                        tlsrpt.TlsRptAnalysisResult
                    )
                    and all(
                        map(
                            lambda res: res.req_10_compliant,
                            results.filter(tlsrpt.TlsRptAnalysisResult),
                        )
                    ),
                    sections=["sec.tlsrpt.inbound"],
                    mandatory=True,
                ),
            ],
        )

    def _get_buildpath(self):
        return self.cwd.name

    @abstractmethod
    def build(self):
        ...

    def render(self, template, params, outfile=None):
        env = JinjaEnvironment(
            loader=PackageLoader("ceti.writer", "dbt_templates"),
            autoescape=select_autoescape(),
            undefined=StrictUndefined,
        )
        t = env.get_template(template)
        text = t.render(**params)

        filepath = join(self._get_buildpath(), outfile if outfile else template)
        logger.debug("rendering %s -> %s", template, filepath)
        with open(filepath, "w", encoding="utf-8") as outfile:
            outfile.write(text)
            logger.debug("successful rendered %s -> %s", template, filepath)

    def render_module(self, results: FilterableList, module: DocumentModule):
        data = module.data(self.environment, results)
        if module.methods:
            for m in module.methods:
                self.render(m, data)
        if module.chapter:
            self.render(module.chapter, data)
        if module.appendix:
            self.render(module.appendix, data)

    def build_report(self, results):

        assert isinstance(results, FilterableList)
        test_config = self.environment.test_config

        versions = {
            "GnuTLS": gnutls_version(),
            "DaneCheck": dane_version(),
            "DNSViz": dnsviz_version(),
            "SSLScan": sslscan_version(),
        }

        ceti_version = "2.0"

        mandatory_compliant = True
        recommended_compliant = True
        for _, module in self.modules.items():
            self.render_module(results, module)
            for requirement in module.compliance:
                if requirement.mandatory:
                    mandatory_compliant = mandatory_compliant and requirement.compliant(
                        results
                    )
                else:
                    recommended_compliant = (
                        recommended_compliant and requirement.compliant(results)
                    )

        params_report = {
            "config": target_as_yaml(test_config.target),
            "target": test_config.target,
            "versions": versions,
            "ceti_version": ceti_version,
            "started_at": datetime.datetime.fromisoformat(test_config.start_time),
            "finished_at": datetime.datetime.fromisoformat(test_config.end_time),
            "generated_at": datetime.datetime.now(),
            "modules": self.modules,
            "analysis_results": results,
            "dns_zones": test_config.dns_configuration,
            "flatten_list": flatten_list,
            "mandatory_compliant": mandatory_compliant,
            "recommended_compliant": recommended_compliant,
        }

        self.render("dbt.properties", {})

        self.render("report.xml", params_report)

        self.build()

        logger.debug("Temporary directory for DBT output is '%s'" % self.cwd.name)

        with open(join(self._get_buildpath(), "out/report.pdf"), "rb") as f:
            generated_at = params_report["generated_at"]
            provider = self.environment.test_config.target.provider
            filename = "report-" + clean_path(f"{generated_at}-{provider}") + ".pdf"
            report = DocbookReport(filename, f.read())

        return report
