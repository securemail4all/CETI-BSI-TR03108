"""
Docbook writer building vanilla docbooks using xslt and fop.
"""

import logging
import subprocess
import os
import glob
from os.path import join

from .docbook import DocbookWriter

logger = logging.getLogger(__name__)


class DocbookPlainWriter(DocbookWriter):
    def build(self):
        outdir = join(self._get_buildpath(), "out")
        os.makedirs(outdir, exist_ok=True)

        cmdline = [
            "sed",
            "-E",
            "-i",
            r"""s#<citation linkend=["']([^'"]+)["']/>#<citation><biblioref linkend="\1"/></citation>#g""",
        ] + glob.glob(join(self._get_buildpath(), "*.xml"))
        logger.debug("Execute %s", cmdline)
        _proc = subprocess.run(
            cmdline,
            cwd=self._get_buildpath(),
            check=True,
            shell=False,
            timeout=10,
        )

        cmdline = [
            "xsltproc",
            "--xinclude",
            "-o",
            "report.fo",
            "--stringparam", "body.start.indent", "0pt",
            "--stringparam", "body.margin.top", "0.8in",
            "--stringparam", "section.autolabel", "1",
            "--stringparam", "section.label.includes.component.label", "1",
            "/app/docbook-stylesheets/fo/docbook.xsl",
            "report.xml",
        ]
        logger.debug("Execute %s", cmdline)
        _proc = subprocess.run(
            cmdline,
            cwd=self._get_buildpath(),
            check=True,
            shell=False,
            timeout=600,
        )

        cmdline = ["fop", "-pdf", join(outdir, "report.pdf"), "-fo", "report.fo"]
        logger.debug("Execute %s", cmdline)
        _proc = subprocess.run(
            cmdline,
            cwd=self._get_buildpath(),
            check=True,
            shell=False,
            timeout=600,
        )
