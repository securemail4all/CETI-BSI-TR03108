from ..utils.python import FilterableList

class BaseWriter():

    def __init__(self, environment):
        self.environment = environment

    def get_name(self):
        return str(self.__class__.__name__)
        
    def build_report(self, results: FilterableList):
        pass
