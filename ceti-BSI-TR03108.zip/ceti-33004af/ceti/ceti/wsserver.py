"""
Implementation of the Websocket Server that enables the web ui to trigger scans.
"""

import asyncio
import json
import logging
import os
import shutil
import sys
import tempfile
import time
import traceback
from datetime import datetime
from enum import Enum

import websockets
from ceti.config import (CetiConfiguration, ValidationError,
                         load_target_config_from_str, save_target_config,
                         target_as_yaml)
from ceti.utils.sanitize import clean_path
from ceti.writer.report import BaseReport
from websockets.server import serve as ws_serve

from ceti.ceti import Ceti

logger = logging.getLogger(__name__)


class Status(str, Enum):
    WAITING = "waiting"
    WORKING = "working"


class WSLogHandler(logging.Handler):

    def __init__(self, wsserver, level=logging.NOTSET):
        super().__init__(level=level)
        self.wsserver = wsserver

    def emit(self, record: logging.LogRecord):
        """
        Emit a log record
        """
        payload = record.getMessage()
        if record.exc_info:
            trace_string = "".join(traceback.format_tb(record.exc_info[2]))
            payload = f"{payload} {record.exc_info[1]} {trace_string}"
            
        msg = json.dumps(
            {
                "type": "message",
                "level": record.levelname,
                "payload": payload,
                "module": record.module,
                "time": datetime.fromtimestamp(record.created).strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
                if hasattr(record, "created")
                else "",
            }
        )
        self.wsserver.wslog(msg)


class WSServer():
    """
    Websocket server exposing the Ceti API.
    """

    def __init__(self, config: CetiConfiguration):
        super().__init__()
        self.outq = None
        self.status = Status.WAITING
        self.clients = []

        self.config = config
        self.port = config.websocket_port
        self.ceti = None

        self.clean_cache()

    def clean_cache(self):
        self.log_cache = []
        self.targetconfig_cache = None
        self.report_cache = None
        self.archive_cache = None

    def set_status(self, status):
        self.status = status
        self.broadcast(json.dumps({"type": "state", "payload": self.status}))

    def wslog(self, msg):
        self.log_cache.append(msg)
        self.broadcast(msg)

    def broadcast(self, msg):
        self.outq.put_nowait(msg)

    def publish_archive(self, config: CetiConfiguration):
        archivefile = config.archive_path
        shutil.move(self.config.archive_path, self.config.webserver_public)
        download_file = os.path.basename(archivefile)
        self.archive_cache = json.dumps({
            "type": "archive",
            "payload": download_file
        })
        self.broadcast(self.archive_cache)

    def publish_reports(self, config: CetiConfiguration, reports: list):
        for report in reports:
            report.store(self.config.webserver_public)
            downloadfile = report.index_file
            self.report_cache = json.dumps({
                "type": "document",
                "payload": downloadfile,
            })
            self.broadcast(self.report_cache)

    def handle_message(self, msg: dict[str, any]):
        """
        Handle message received via websocket. 
        The message must be pre-parsed as dict
        """

        function = None

        try:
            function = msg["function"]
        except KeyError as exception:
            logger.error("Malformed websocket call: ", exc_info=exception)
            return

        if function == "clear":
            try:
                self.clean_cache()
                shutil.rmtree(self.config.webserver_public, ignore_errors=True)
                self.broadcast(json.dumps({"type": "clear", "payload": ""}))
            except Exception as e:
                logger.error("Exception occurred during %s() call",
                             "clear", exc_info=e)
            finally:
                self.set_status(Status.WAITING)
                return

        if function == "stop":
            logger.warning("Stopping CETI")
            # suicide: docker will restart ceti
            sys.exit(1)
            return

        if function in ["analyze", "scan", "create_new_reports"]:
            arguments = None
            targetconfig = None

            if self.status == Status.WORKING:
                logger.error("CETI scan already in progress")
                return
            else:
                shutil.rmtree(self.config.webserver_public, ignore_errors=True)
                self.set_status(Status.WORKING)

            try:
                arguments = msg["arguments"]
                targetconfig = arguments["config"]
            except KeyError as exception:
                logger.error("Malformed websocket call: ", exc_info=exception)
                self.set_status(Status.WAITING)
                return

            try:
                targetconfig = load_target_config_from_str(targetconfig)
                self.targetconfig_cache = targetconfig
            except ValidationError as exception:
                logger.error("Syntax error in configuration file: ",
                             exc_info=exception)
                self.set_status(Status.WAITING)
                return

            self.broadcast(
                json.dumps({
                    "type": "config",
                    "payload": target_as_yaml(self.targetconfig_cache),
                })
            )

            # create a scan id
            timestr = time.strftime("%Y%m%d-%H%M%S")
            name = clean_path(targetconfig.provider)
            scanid = f"{timestr}-{name}"

            # use tmpdir for archive and target in web mode
            # overrides default config
            tmp = tempfile.TemporaryDirectory()

            target_file = os.path.join(
                tmp.name, f"{scanid}-target.yaml")
            save_target_config(target_file, targetconfig)
            self.config.target_path = target_file

            archive_file = os.path.join(
                tmp.name, f"{scanid}-archive.yaml")
            self.config.archive_path = archive_file

            # create ceti 
            ceti = Ceti(self.config)
            ceti_callable = getattr(ceti, function)
            logger.debug("Calling '%s'()", function)

            async def perform_scan():
                try:
                    reports = await asyncio.to_thread(ceti_callable)
                    self.publish_reports(self.config, reports)
                    logger.info("Report ready")
                except Exception:
                    logger.exception("Unexpected error")
                try:
                    self.set_status(Status.WAITING)
                    self.publish_archive(self.config)
                    tmp.cleanup() # keep reference of tmp until the report is ready and archive is published
                except Exception as error:
                    logger.error("Failed to publish archive: %s" % str(error))

            # run ceti
            asyncio.create_task(perform_scan())
            

    async def sync_client(self, client):
        await self.try_send(client, json.dumps({"type": "state", "payload": self.status}))
        if self.report_cache:
            await self.try_send(client, self.report_cache)
        if self.archive_cache:
            await self.try_send(client, self.archive_cache)
        for log in self.log_cache:
            await self.try_send(client, log)
        if self.targetconfig_cache:
            await self.try_send(
                client,
                json.dumps(
                    {
                        "type": "config",
                        "payload": target_as_yaml(self.targetconfig_cache),
                    }
                ),
            )

    async def handle_client(
        self, client: websockets.server.WebSocketServerProtocol, _path: str
    ):

        await self.sync_client(client)
        self.clients.append(client)
        try:
            while True:
                try:
                    data = await client.recv()
                    if not data:
                        break
                    self.handle_message(json.loads(data))
                except json.JSONDecodeError as exception:
                    logger.error("Error decoding websocket message",
                                 exc_info=exception)
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.clients.remove(client)

    async def try_send(self, client, data):
        try:
            await client.send(data)
        except websockets.exceptions.WebSocketException:
            pass

    async def drain_outq(self):
        self.outq = asyncio.Queue()

        while True:
            msg = await self.outq.get()
            for c in self.clients:
                try:
                    await c.send(msg)
                except websockets.exceptions.WebSocketException:
                    pass

    async def start_async(self):
        """
        Start the websocket server and use it for ceti logging
        """
        async with ws_serve(self.handle_client, "0.0.0.0", self.port):
            await self.drain_outq()  # run forever

    def start(self):
        """
        Start the websocket server synchronously
        """
        logging.debug("starting websocket on port %d", self.port)
        asyncio.run(self.start_async())
