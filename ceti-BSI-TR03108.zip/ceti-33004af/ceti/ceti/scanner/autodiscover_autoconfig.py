import datetime
import logging
from dataclasses import dataclass
from typing import Optional

from ..api import tls_analyze_invocation, tls_scan_host
from ..api.autodiscover_autoconfig import (get_response, get_srv_entries, parse_autoconfig,
                                           parse_autodiscover, split_url_port)
from ..api.tls import TlsAnalysisResult
from ..api.tls.sslscan import SslScanInvocation
from ..utils.python import FilterableList, unique_id
from .base import BaseScanner

logger = logging.getLogger(__name__)

@dataclass
class SRVData:
    # dnssec_result: DNSSecResult
    srv_entries: list[list]

@dataclass
class Url_response:
    url: str
    port: str
    data: bytes
    tls_invo: Optional[SslScanInvocation] = None

@dataclass
class AutoconfigScanResult:
    response: list[Url_response]

@dataclass
class AutodiscoverScanResult:
    response: list[Url_response]
    srv_data: SRVData

@dataclass
class AutodiscoverAutoconfigScanResult:
    autodiscover: AutodiscoverScanResult
    autoconfig: AutoconfigScanResult
    e21_data: list[list]
    e22_data: list[list]
    e23_data: list[list]
    started: str
    version: str = "1.0"

@dataclass
class Protocol:
    name: str
    direction: str
    hostname: str
    port: str
    SSL: bool
    STARTTLS: bool

@dataclass
class ParsedURL:
    url: str
    valid_xml: bool
    data: bytes
    protocols: list[Protocol]

@dataclass
class Errors:
    protocols_without_ssl: list[Protocol]
    not_listed_protocols: list[Protocol] 
    wrong_hostname_port: list[Protocol]
    starttls_entries: list[Protocol]
    missing_protocols: list[str]


@dataclass
class GenericAnalyzeResult:
    unique_id: str
    result: list[ParsedURL]
    valid_xml: bool
    all_protocols: list[Protocol]
    used_url: str
    used_data: str
    supported: bool
    errors: Errors
    used_domain_tls_scan: Optional[TlsAnalysisResult] = None


@dataclass
class EntryFinding:
    result: bool
    wrong: list[Protocol]
    starttls: list[Protocol]

@dataclass
class AutodiscoverAnalyzeResult:
    result: GenericAnalyzeResult
    srv_data: SRVData
    e13: bool
    e14: EntryFinding
    e15: EntryFinding
    e16: EntryFinding

@dataclass
class AutoconfigAnalyzeResult:
    result: GenericAnalyzeResult
    e17: bool
    e18: EntryFinding
    e19: EntryFinding
    e20: EntryFinding

@dataclass
class AutodiscoverAutoconfigAnalyzeResult:
    autoconfig: AutoconfigAnalyzeResult
    autodiscover: AutodiscoverAnalyzeResult
    compliant: bool
    e21: bool
    e21_err: list[str]
    e21_srv: list[str]
    e22: bool
    e22_err: list[str]
    e22_srv: list[str]
    e23: bool
    e23_err: list[str]
    e23_srv: list[str]
    started: str
    version: str

class AutodiscoverAutoconfigScanner(BaseScanner):

    def __init__(self, environment):
        super().__init__(environment)

    def scan(self):
        domains = self.environment.test_config.target.domains
        started=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        autoconfig_urls = []
        for domain in domains:
            autoconfig_urls.append(("https://autoconfig.{}/mail/config-v1.1.xml?emailaddress=info@{}".format(domain, domain), "autoconfig.{}".format(domain), "443"))
            autoconfig_urls.append(("https://autoconfig.{}/mail/config-v1.1.xml".format(domain), "autoconfig.{}".format(domain), "443"))
            autoconfig_urls.append(("https://{}/.well-known/autoconfig/mail/config-v1.1.xml".format(domain), "autoconfig.{}".format(domain), "443"))
        autoconfig_result = []
        for url in autoconfig_urls:
            data = get_response(url[0])
            tls_invo = None
            try:
                tls_invo = None if data == b'' else tls_scan_host(host=url[1], port=url[2])
            except Exception as e:
                logger.error("Error in tls_scan_host (host: {}, port: {}), Error: {}".format(url[1], url[2], e))
                tls_invo = None
            autoconfig_result.append(Url_response(url=url[0], 
                port=url[2], 
                tls_invo=tls_invo,
                data=data))
        autoconfig = AutoconfigScanResult(response=autoconfig_result)

        _srv_entries = []
        _srv_entries.append((domain, "443"))
        for domain in domains:
            srv_entries = get_srv_entries(domain)
            for s in srv_entries:
                if s != (domain, "443"):
                    _srv_entries.append(s)

        autodiscover_urls = []
        for domain, port in _srv_entries:
            autodiscover_urls.append(("https://{}:{}/autodiscover/autodiscover.xml".format(domain, port), domain, port, tls_invo ))
            autodiscover_urls.append(("https://autodiscover.{}:{}/autodiscover/autodiscover.xml".format(domain, port), domain, port, tls_invo ))
        autodiscover_result = []
        for url in autodiscover_urls:
            data = get_response(url[0])
            tls_invo = None
            try:
                tls_invo = None if data == b'' else tls_scan_host(host=url[1], port=url[2])
            except Exception as e:
                logger.error("Error in tls_scan_host (host: {}, port: {}), Error: {}".format(url[1], url[2], e))
                tls_invo = None
            autodiscover_result.append(Url_response(
                url=url[0], 
                port=str(url[2]), 
                tls_invo=tls_invo,
                data=data))
        autodiscover = AutodiscoverScanResult(response=autodiscover_result, 
            srv_data=SRVData(
                #dnssec_result=dnssec_result,
                srv_entries=srv_entries))

        smtps_srv_entries = []
        imaps_srv_entries = []
        pop3s_srv_entries = []
        for domain in domains:
            smtps_srv_entries += get_srv_entries(domain, suffix="_SUBMISSION")
            imaps_srv_entries += get_srv_entries(domain, suffix="_IMAPS")
            pop3s_srv_entries += get_srv_entries(domain, suffix="_POP3S")

        return AutodiscoverAutoconfigScanResult(
            autodiscover=autodiscover, 
            autoconfig=autoconfig,
            e21_data=smtps_srv_entries,
            e22_data=imaps_srv_entries,
            e23_data=pop3s_srv_entries,
            started=started)

    def analyze(self, results):
        all_response = results.filter(AutodiscoverAutoconfigScanResult)[0]
        #logger.error(all_response.autodiscover.srv_data)
        
        autodiscover_scan_data = all_response.autodiscover
        autoconfig_scan_data = all_response.autoconfig
        e21_data = all_response.e21_data
        e22_data = all_response.e22_data
        e23_data = all_response.e23_data
        started = all_response.started
        version = all_response.version

        starttls_smtp_expected = split_url_port(self.environment.test_config.target.services.get("starttls-smtp"))
        starttls_pop3_expected = split_url_port(self.environment.test_config.target.services.get("starttls-pop3"))
        starttls_imap_expected = split_url_port(self.environment.test_config.target.services.get("starttls-imap"))
        tls_smtp_expected = split_url_port(self.environment.test_config.target.services.get("tls-smtp"))
        tls_pop3_expected = split_url_port(self.environment.test_config.target.services.get("tls-pop3"))
        tls_imap_expected = split_url_port(self.environment.test_config.target.services.get("tls-imap"))

        _e21_data = [(a, str(b)) for (a,b) in e21_data]
        e21_err = self._get_errs(_e21_data, starttls_smtp_expected, tls_smtp_expected)
        _e22_data = [(a, str(b)) for (a,b) in e22_data]
        e22_err = self._get_errs(_e22_data, starttls_imap_expected, tls_imap_expected)
        _e23_data = [(a, str(b)) for (a,b) in e23_data]
        e23_err = self._get_errs(_e23_data, starttls_pop3_expected, tls_pop3_expected)

        autodiscover=self._analyze(
            autodiscover_scan_data, 
            # autodiscover_scan_data.srv_data.dnssec_result, 
            autoconfig=False)
        autoconfig=self._analyze(
            autoconfig_scan_data, 
            # autodiscover_scan_data.srv_data.dnssec_result, 
            autoconfig=True)

        autoconfig_result=AutoconfigAnalyzeResult(
            result=autoconfig,
            e17=autoconfig.used_url != "" and 
                autoconfig.used_domain_tls_scan and 
                autoconfig.used_domain_tls_scan.is_conform, # and 
                # autoconfig.errors.not_listed_protocols == [],
            e18=self._is_supported("SMTP", autoconfig),
            e19=self._is_supported("IMAP", autoconfig),
            e20=self._is_supported("POP3", autoconfig))

        autodiscover_result = AutodiscoverAnalyzeResult(
                    result=autodiscover, 
                    srv_data=autodiscover_scan_data.srv_data,
                    e13=autodiscover.used_url != "" and 
                        autodiscover.used_domain_tls_scan and 
                        autodiscover.used_domain_tls_scan.is_conform, # and 
                        # autodiscover.errors.not_listed_protocols == [], # and 
                        # autodiscover_scan_data.srv_data.dnssec_result.compliant,
                    e14=self._is_supported("SMTP", autodiscover),
                    e15=self._is_supported("IMAP", autodiscover),
                    e16=self._is_supported("POP3", autodiscover))

        e21_result=len(e21_err)==0 and len(e21_data)>0
        e22_result=len(e22_err)==0 and len(e22_data)>0
        e23_result=len(e23_err)==0 and len(e23_data)>0

        compliant = autodiscover_result.e13 and \
            autodiscover_result.e14.result and \
            autodiscover_result.e15.result and \
            autodiscover_result.e16.result and \
            autoconfig_result.e17 and \
            autoconfig_result.e18.result and \
            autoconfig_result.e19.result and \
            autoconfig_result.e20.result and \
            e21_result and \
            e22_result and \
            e23_result
        result = AutodiscoverAutoconfigAnalyzeResult(
                autoconfig=autoconfig_result,
                autodiscover=autodiscover_result,
                e21=e21_result,
                e21_err=e21_err,
                e21_srv=e21_data,
                e22=e22_result,
                e22_err=e22_err,
                e22_srv=e22_data,
                e23=e23_result,
                e23_err=e23_err,
                e23_srv=e23_data,
                compliant=compliant,
                started=started,
                version=version
            )
        #logger.error(result)
        return result

    def _get_errs(self, w_data, c_data_starttls, c_data_tls):
        errs = []
        for d in w_data:
            d = (d[0], str(d[1]))
            if d not in c_data_tls and d not in c_data_starttls:
                errs.append("{}:{} wird durch den DNS SRV Record definiert, ist aber nicht in der Testkonfiguration enthalten und daher nicht Teil der Untersuchung.".format(d[0], d[1]))
            elif d not in c_data_tls and d in c_data_starttls:
                errs.append("{}:{} wird durch den DNS SRV Record definiert, ist aber nicht in der Testkonfiguration als TLS-Server definiert".format(d[0], d[1]))
        return errs

    def _is_supported(self, protocol_name, data):
        errors = data.errors
        xml_wrong = []
        starttls = []
        result = True

        if data.used_url == "":
            result = False

        for p in errors.starttls_entries:
            if p.name == protocol_name:
                result = False
                starttls.append(p)

        for p in errors.protocols_without_ssl:
            if p.name == protocol_name and not p.SSL:
                result = False

        for p in errors.wrong_hostname_port:
            if p.name == protocol_name:
                result = False
                xml_wrong.append(p)

        if protocol_name in errors.missing_protocols:
            result = True

        return EntryFinding(result=result, wrong=xml_wrong, starttls=starttls)

    def _analyze(self, scan_data, dnssec_result=None, autoconfig=False):
        starttls_smtp_expected = split_url_port(self.environment.test_config.target.services.get("starttls-smtp"))
        starttls_pop3_expected = split_url_port(self.environment.test_config.target.services.get("starttls-pop3"))
        starttls_imap_expected = split_url_port(self.environment.test_config.target.services.get("starttls-imap"))
        tls_smtp_expected = split_url_port(self.environment.test_config.target.services.get("tls-smtp"))
        tls_pop3_expected = split_url_port(self.environment.test_config.target.services.get("tls-pop3"))
        tls_imap_expected = split_url_port(self.environment.test_config.target.services.get("tls-imap"))
        smtp_expected = starttls_smtp_expected + tls_smtp_expected
        imap_expected = starttls_imap_expected + tls_imap_expected
        pop3_expected = starttls_pop3_expected + tls_pop3_expected

        full_result = []
        used_url = ""
        used_data = ""
        supported = False
        used_domain_tls_scan = None
        protocols_without_ssl = []
        not_listed_protocols = []
        missing_protocols = []
        protocols = []
        starttls_entries = []

        wrong_hostname_port = []

        for result in scan_data.response:
            if autoconfig:
                valid_xml, parsed_data = parse_autoconfig(result.data)
            else:
                valid_xml, parsed_data = parse_autodiscover(result.data)
           

            if valid_xml:
                # check if all three protocols are listed
                supported = []
                for p in parsed_data:
                    supported.append(p.get("protocol_name"))
                for p in ["SMTP", "POP3", "IMAP"]:
                    if p not in supported:
                        missing_protocols.append(p)

                # check if any protocols outside of smtp, pop3 and imap are listed
                # check if SSL is supported
                for p in parsed_data:
                    proto = Protocol(
                        name=p.get("protocol_name"),
                        direction=p.get("direction") if "direction" in p.keys() else "",
                        hostname=p.get("hostname"),
                        port=p.get("port"),
                        SSL=p.get("SSL"),
                        STARTTLS=p.get("STARTTLS"))
                    protocols.append(proto)
                    if proto.name not in ["SMTP", "POP3", "IMAP"]:
                        not_listed_protocols.append(proto)
                    else:
                        if proto.SSL == False and proto.STARTTLS == False:
                            protocols_without_ssl.append(proto)

                # check if hostname and port match to the config file
                _smtp_hostname_ports = []
                _pop3_hostname_ports = []
                _imap_hostname_ports = []

                for p in protocols:
                    if p.STARTTLS:
                        starttls_entries.append(p)
                    if p.name == "SMTP":
                        _smtp_hostname_ports.append((p.hostname, p.port, p.SSL, p.STARTTLS))
                        if autoconfig and p.STARTTLS:
                            if (p.hostname, p.port) not in starttls_smtp_expected:
                                wrong_hostname_port.append(p)
                        elif autoconfig and p.SSL:
                            if (p.hostname, p.port) not in tls_smtp_expected:
                                wrong_hostname_port.append(p)
                        elif not autoconfig:
                            if (p.hostname, p.port) not in smtp_expected:
                                wrong_hostname_port.append(p)
                    if p.name == "IMAP":
                        _imap_hostname_ports.append((p.hostname, p.port, p.SSL, p.STARTTLS))
                        if autoconfig and p.STARTTLS:
                            if (p.hostname, p.port) not in starttls_imap_expected:
                                wrong_hostname_port.append(p)
                        elif autoconfig and p.SSL:
                            if (p.hostname, p.port) not in tls_imap_expected:
                                wrong_hostname_port.append(p)
                        elif not autoconfig:
                            if (p.hostname, p.port) not in imap_expected:
                                wrong_hostname_port.append(p)
                    if p.name == "POP3":
                        _pop3_hostname_ports.append((p.hostname, p.port, p.SSL, p.STARTTLS))
                        if autoconfig and p.STARTTLS:
                            if (p.hostname, p.port) not in starttls_pop3_expected:
                                wrong_hostname_port.append(p)
                        elif autoconfig and p.SSL:
                            if (p.hostname, p.port) not in tls_pop3_expected:
                                wrong_hostname_port.append(p)
                        elif not autoconfig:
                            if (p.hostname, p.port) not in pop3_expected:
                                wrong_hostname_port.append(p)

            full_result.append(ParsedURL(
                url=result.url,
                data=result.data,
                valid_xml=valid_xml,
                protocols=protocols
            ))
            if valid_xml:
                used_url = result.url
                used_data = result.data.decode("utf-8")
                if result.tls_invo:
                    used_domain_tls_scan = tls_analyze_invocation(result.tls_invo)
                else:
                    used_domain_tls_scan = None
                supported = True
                break

        full_result = GenericAnalyzeResult(
            unique_id=unique_id(),
            result=full_result, 
            used_url=used_url,
            valid_xml=valid_xml,
            all_protocols=protocols,
            used_data=used_data,
            used_domain_tls_scan=used_domain_tls_scan,
            supported=supported, 
            errors=Errors(
                protocols_without_ssl=protocols_without_ssl,
                starttls_entries=starttls_entries,
                not_listed_protocols=not_listed_protocols,
                wrong_hostname_port=wrong_hostname_port, 
                missing_protocols=missing_protocols),
            )

        return full_result
