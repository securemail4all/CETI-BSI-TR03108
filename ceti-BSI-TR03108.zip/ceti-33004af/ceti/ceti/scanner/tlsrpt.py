"""
TLSRPT scanner
"""

from dataclasses import dataclass, field

import datetime
import logging
import json
import re

from ceti.api import (
    tlsrpt_validate_dnsrecord,
    tlsrpt_validate_report,
    tlsrpt_extract_report,
    dnssec_analyze,
    dnsviz_probe_rdtype,
    dnsviz_txt,
)
from ceti.api.types import DNSSecResult, DnsVizProbeScanResult, TxtRecord

from ceti.utils.python import FilterableList, unique_id
from ceti.config import Mail

from .base import BaseScanner

logger = logging.getLogger(__name__)


@dataclass
class DomainScanResult:
    """ """

    domain: str
    dns_records: list[TxtRecord]
    dnssec: DnsVizProbeScanResult


@dataclass
class TlsRptScanResult:
    """ """

    started: str
    results: list[DomainScanResult]
    smtp_reports: list[Mail]
    https_reports: list[str]
    version: str = "1.0"


@dataclass
class ValidatedTxtRecord:
    """ """

    record: TxtRecord
    valid: bool
    dnssec: DNSSecResult
    test_id: int


@dataclass
class EmailReport:
    """ """

    mail: Mail
    report: dict


@dataclass
class TlsRptAnalysisResult:
    """ """

    # pylint: disable=too-many-instance-attributes
    started: str
    version: str
    txt_records: list[ValidatedTxtRecord] = field(default_factory=list)
    https_reports: list[dict] = field(default_factory=list)
    smtp_reports: list[EmailReport] = field(default_factory=list)
    smtp_report_dkim: bool = False
    g01: bool = False
    g02: bool = False
    g03: bool = False
    h01: bool = False
    h02: bool = False
    h03: bool = False
    h04: bool = False
    h05: bool = False
    h06: bool = False
    h07: bool = False
    h08: bool = False
    h09: bool = False
    h10: bool = False
    req_09_compliant: bool = False
    req_10_compliant: bool = False


TXT_REGEX = re.compile(r'"(?:\\.|[^"\\])*"')


class TlsRptScanner(BaseScanner):
    """
    Execute tests of Test Modules G and H.
    """

    def __init__(self, environment):
        super().__init__(environment)

    def _query_dns(self, domain):
        """
        Retrieve the TLSRPT resoruce record. This function also performs the dnssec validation using
        dnsviz.

        Args:
            domain (str): the domain whose TLSRPT resource record should be queried

        Returns:
            A tuple (DnsVizProbeScanResult, list[TxtRecord]) containing the DNSSEC validation result
            and the resource records found.
        """
        query = f"_smtp._tls.{domain}"

        logger.info("Querying TXT %s", query)

        result = []
        probe = dnsviz_probe_rdtype(query, "TXT")
        records = dnsviz_txt(probe)
        for record in records:
            logger.info("Record found: %s", record)
            rpt_record = TxtRecord(text=record, query=query)
            result.append(rpt_record)

        return probe, result

    def scan(self):
        """
        Perform the actual scan. The inbound tests (Module G) are performed primarily in this part
        of the Scanner.

        Returns:
            A single TlsRptScanResult representing the scan result. This result enables the
            TlsRptScanner.analyze method to execute the conformance analysis.
        """
        domain_results = []
        logger.info("Performing inbound tests")
        result = TlsRptScanResult(
            started=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            results=domain_results,
            smtp_reports=[],
            https_reports=[],
        )
        for domain in self.environment.test_config.target.domains:
            logger.debug("scanning domain %s", domain)
            dnssec, records = self._query_dns(domain)

            domain_result = DomainScanResult(
                domain=domain, dns_records=records, dnssec=dnssec
            )
            result.results.append(domain_result)

        logger.info("Performing outbound tests")
        # Find TLS report mails for MHS 'outbound' tests
        result.smtp_reports = list(
            filter(
                lambda mail: mail.recipient.startswith("tlsrpt@"),
                self.environment.mailstore,
            )
        )

        result.https_reports = []
        for rpt in self.environment.tlsrpt_https_store:
            print(rpt)
            if 'text' in rpt:
                result.https_reports.append(str(rpt['text'], 'utf-8', 'surrogateescape'))

        return result

    def _analyze_https_reports(self, reports):
        result = []
        for report in reports:
            try:
                report = json.loads(report)
                if tlsrpt_validate_report(
                    report, self.environment.test_config.target.organization_name
                ):
                    result.append(report)
            except json.JSONDecodeError:
                pass
        return result

    def _analyze_smtp_reports(self, reports: list[Mail]) -> list[EmailReport]:
        result = []
        for report_mail in reports:
            try:
                domain, report = tlsrpt_extract_report(report_mail.message)
                if (
                    domain
                    and report
                    and tlsrpt_validate_report(
                        report, self.environment.test_config.target.organization_name
                    )
                ):
                    result.append(EmailReport(mail=report_mail, report=report))

            except json.JSONDecodeError:
                pass
        return result

    def analyze(self, results: FilterableList):
        scan_results: list[TlsRptScanResult] = results.filter(TlsRptScanResult)
        analysis_results = []
        for result in scan_results:
            analysis_result = TlsRptAnalysisResult(
                started=result.started,
                version=result.version,
            )
            for domain in result.results:
                validated_records = []
                for record in domain.dns_records:
                    valid = tlsrpt_validate_dnsrecord(record)
                    dnssec_result = dnssec_analyze(domain.dnssec)
                    validated_records.append(
                        ValidatedTxtRecord(
                            record=record,
                            valid=valid,
                            dnssec=dnssec_result,
                            test_id=unique_id()
                        )
                    )

                analysis_result.txt_records.extend(validated_records)

            analysis_result.https_reports = self._analyze_https_reports(
                result.https_reports
            )
            analysis_result.smtp_reports = self._analyze_smtp_reports(
                result.smtp_reports
            )
            analysis_result.smtp_report_dkim = any(
                map(lambda rpt: rpt.mail.dkim_valid, analysis_result.smtp_reports)
            )

            analysis_result.h01 = (
                len(analysis_result.smtp_reports) > 0
                or len(analysis_result.https_reports) > 0
            )
            analysis_result.h02 = (
                "tlsrpt@" + self.environment.ceti_config.zones.tlsrpt_ver_none
                not in map(lambda rpt: rpt.mail.recipient, analysis_result.smtp_reports)
            )
            analysis_result.h03 = (
                "tlsrpt@" + self.environment.ceti_config.zones.tlsrpt_ver_bad
                not in map(lambda rpt: rpt.mail.recipient, analysis_result.smtp_reports)
            )
            analysis_result.h04 = (
                "tlsrpt@" + self.environment.ceti_config.zones.tlsrpt_rua_none
                not in map(lambda rpt: rpt.mail.recipient, analysis_result.smtp_reports)
            )
            analysis_result.h05 = len(analysis_result.https_reports) > 0
            analysis_result.h06 = len(analysis_result.smtp_reports) > 0
            analysis_result.h07 = analysis_result.smtp_report_dkim

            # Negotiation Failure should be found as zone tlsrpt_bad_negotiation uses
            # mtasts-untrusted-mhs mailserver
            analysis_result.h08 = False
            for rpt in analysis_result.smtp_reports:
                if (
                    rpt.mail.recipient
                    == "tlsrpt@" + self.environment.ceti_config.zones.tlsrpt_bad_negotiation
                ):
                    for policy_report in rpt.report["policies"]:
                        if policy_report["summary"]["total-failure-session-count"] > 0:
                            analysis_result.h08 = True


            # Policy Failure should be found as zone tlsrpt_bad_policy uses
            # "ABRA-KADABRA\n" as mtasts policy
            analysis_result.h09 = False
            for rpt in analysis_result.smtp_reports:
                if (
                    rpt.mail.recipient
                    == "tlsrpt@" + self.environment.ceti_config.zones.tlsrpt_bad_policy
                ):
                    for policy_report in rpt.report["policies"]:
                        if policy_report["summary"]["total-failure-session-count"] > 0:
                            analysis_result.h09 = True

            # FIXME H10 cannot be implemented as it is not known when this error is triggered
            analysis_result.h10 = False
            for rpt in analysis_result.smtp_reports:
                if (
                    rpt.mail.recipient
                    == "tlsrpt@" + self.environment.ceti_config.zones.tlsrpt_bad_general
                ):
                    for policy_report in rpt.report["policies"]:
                        if policy_report["summary"]["total-failure-session-count"] > 0:
                            analysis_result.h10 = True

            # Positive test evaluating the presence and correctness of the
            # TLSRPT TXT Resource Record
            analysis_result.g01 = len(analysis_result.txt_records) > 0 and all(
                map(
                    lambda record: isinstance(record.valid, bool) and record.valid,
                    analysis_result.txt_records,
                )
            )

            # Positive Test evaluating the absence of a HTTPS report policy.
            analysis_result.g02 = all(
                map(
                    lambda record: "https://" not in record.record.text.lower(),
                    analysis_result.txt_records,
                )
            )

            # Positive Test evaluating the presence of a MAILTO report policy.
            analysis_result.g03 = any(
                map(
                    lambda record: "mailto:" in record.record.text.lower(),
                    analysis_result.txt_records,
                )
            )

            analysis_result.req_09_compliant = (
                analysis_result.h01
                and analysis_result.h02
                and analysis_result.h03
                and analysis_result.h04
                and analysis_result.h05
                and analysis_result.h06
                and analysis_result.h07
                and analysis_result.h08
                and analysis_result.h09
                # and analysis_result.h10
            )
            analysis_result.req_10_compliant = (
                analysis_result.g01 and analysis_result.g02 and analysis_result.g03
            )
            analysis_results.append(analysis_result)
        return analysis_results
