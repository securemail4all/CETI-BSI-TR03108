import json
import dns
import uuid

from dataclasses import dataclass
from typing import Union

from ceti.api import dane_receive_tlsa_records
from ceti.api import dane_version
from ceti.api import dane_tlsa_is_compliant

from ceti.api import dnsviz_probe_rdtype
from ceti.api import dnsviz_mx
from ceti.api import dnssec_analyze
from ceti.api.types import DNSSecResult, DnsVizProbeScanResult

from ..config import Mail
from ..utils.python import unique_id
from ..utils.python import flatten_list
from .base import BaseScanner


@dataclass
class DaneMailScanResult:
    recipient: str
    sender: str
    mail: Mail


@dataclass
class DaneCheckScanResult:
    host: str
    port: int
    result: list[dict]
    dane_check_version: str


@dataclass
class DaneCheckResult:
    host: str
    port: int
    compliant: bool
    data: list[dict]
    dane_check_version: str


@dataclass
class TR03108_C_XX_Result:
    test_name: str
    test_id: str
    zone: str
    compliant: bool
    mail_received: bool
    recipient: Union[str, None]
    sender: Union[str, None]
    mail: Union[Mail, None]
    


@dataclass
class TR03108_D_01_Result:
    test_name: str
    test_id: str
    compliant: bool
    results: list[DNSSecResult]


@dataclass
class TR03108_D_02_Result:
    test_name: str
    test_id: str
    compliant: bool
    results: list[DaneCheckResult]


class DaneScanner(BaseScanner):
    def __init__(self, environment):
        super().__init__(environment)

        zones = environment.ceti_config.zones
        self.testcases = {
            "TR-03108-C-01-T": (zones.dnssec, True),
            "TR-03108-C-02": (zones.ksk_bad_sig, False),
            "TR-03108-C-03": (zones.expired_ksk, False),
            "TR-03108-C-04-T": (zones.dane, True),
            "TR-03108-C-05": (zones.tlsa_bad_sig, False),
            "TR-03108-C-06": (zones.tlsa_exp, False),
            "TR-03108-C-07": (zones.tlsas_ok, True),
            "TR-03108-C-08": (zones.tlsa_ca_cert, False),
            "TR-03108-C-09": (zones.sf_nmatch, False),
        }

    def _extract_domain_from_mail(self, mail):
        return mail.split("@")[1]

    def _extract_host_from_sockaddr(self, sockaddr):
        return sockaddr.split(":")[0]

    def _inbound_scan(self):
        mx = []
        results = []
        target = self.environment.test_config.target

        # probe MX
        for domain in set(target.domains):
            probe = dnsviz_probe_rdtype(domain, "MX")
            results.append(probe)
            mx = dnsviz_mx(probe)

        # probe A,AAAA
        for domain in set(mx):
            for rdtype in ["A", "AAAA"]:
                probe = dnsviz_probe_rdtype(domain, rdtype)
                results.append(probe)

        # probe TLSA
        for domain in set(mx):
            domain = "_25._tcp." + domain
            probe = dnsviz_probe_rdtype(domain, "TLSA")
            results.append(probe)

        # DaneCheck TLSA recorads
        for domain in set(mx):
            result = DaneCheckScanResult(
                host=domain,
                port=25,
                result=dane_receive_tlsa_records(domain, 25),
                dane_check_version=dane_version(),
            )
            results.append(result)

        return results

    def _inbound_analyze(self, scans):
        dnssec = TR03108_D_01_Result(
            test_name="TR-03108-D-01", 
            test_id=unique_id(),
            compliant=True, 
            results=[]
        )

        for scan in scans.filter(DnsVizProbeScanResult):
            result = dnssec_analyze(scan)

            dnssec.results.append(result)
            if dnssec.compliant:
                dnssec.compliant = result.compliant

        tlsa = TR03108_D_02_Result(
            test_name="TR-03108-D-02",
            test_id=unique_id(),
            compliant=True,
            results=[],
        )

        for scan in scans.filter(DaneCheckScanResult):
            result = DaneCheckResult(
                host=scan.host,
                port=scan.port,
                compliant=dane_tlsa_is_compliant(scan.result),
                data=scan.result,
                dane_check_version=scan.dane_check_version,
            )

            tlsa.results.append(result)
            if tlsa.compliant:
                tlsa.compliant = result.compliant

        return [tlsa, dnssec]

    def _outbound_scan(self):
        results = []

        store = self.environment.mailstore
        targetmail = self.environment.test_config.target.mail

        # extract all emails sent to relevant zones
        for mail in store.from_sender(targetmail):
            for testname, testcase in self.testcases.items():
                zone, _ = testcase
                if self._extract_domain_from_mail(mail.recipient) == zone:
                    result = DaneMailScanResult(
                        recipient=mail.recipient, 
                        sender=mail.sender, 
                        mail=mail
                    )
                    results.append(result)

        return results

    def _outbound_analyze(self, scans):
        results = []

        for testname, testcase in self.testcases.items():
            zone, expected = testcase
            received = False
            store_mail = None
            recipient = None
            sender = None
            starttls = False

            for scan in scans.filter(DaneMailScanResult):
                if self._extract_domain_from_mail(scan.recipient) == zone:
                    received = True
                    store_mail = scan.mail
                    recipient = scan.recipient
                    sender = scan.sender
                    starttls = scan.mail.starttls
                    break

            result = TR03108_C_XX_Result(
                test_name=testname,
                test_id=unique_id(),
                zone=zone,
                compliant=(expected == received) and (received == starttls),
                mail_received=received,
                recipient=recipient,
                sender=sender,
                mail=store_mail,
            )

            results.append(result)

        return results

    def scan(self):
        ret = []
        ret.extend(self._inbound_scan())
        ret.extend(self._outbound_scan())
        return ret

    def analyze(self, scans):
        ret = []
        ret.extend(self._inbound_analyze(scans))
        ret.extend(self._outbound_analyze(scans))
        return ret
