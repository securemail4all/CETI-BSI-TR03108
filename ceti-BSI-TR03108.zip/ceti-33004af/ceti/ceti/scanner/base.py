"""
An abstract base class for scanners.
"""

from ceti.environment import Environment
from ceti.utils.python import FilterableList

class BaseScanner():

    def __init__(self, environment: Environment):
        self.environment = environment

    def get_name(self):
        return str(self.__class__.__name__)

    def scan(self):
        pass

    def analyze(self, results: FilterableList):
        pass
