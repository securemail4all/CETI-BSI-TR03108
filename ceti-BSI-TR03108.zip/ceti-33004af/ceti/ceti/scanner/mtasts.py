"""
MTA-STS scanner.
Scan and analyze MTA-STS (`RFC 8461 <https://datatracker.ietf.org/doc/html/rfc8461.html>`_)
according to TR-03108.
"""

from dataclasses import dataclass, field
from typing import Optional
import fnmatch
import logging
import ssl
import dns.exception

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.x509.oid import NameOID
from cryptography.x509.extensions import ExtensionNotFound
import requests

from ceti.utils.python import unique_id
from ceti.api.types import TxtRecord, DnsVizProbeScanResult
from ceti.api import (
    dnsviz_probe_rdtype,
    dnsviz_txt,
    dnsviz_mx,
    tls_scan_host,
    tls_analyze_invocation,
)
from ceti.api.tls import SslScanInvocation, TlsAnalysisResult
from ceti.config import Mail

from .base import BaseScanner

logger = logging.getLogger(__name__)


@dataclass
class MtaStsScanResult:
    text_records: list[TxtRecord]
    domain: str
    domain_mxs: DnsVizProbeScanResult
    sts_record: DnsVizProbeScanResult
    tls_scan: Optional[SslScanInvocation]
    tls_cert: Optional[str]
    policy_subdomain: str
    policy: Optional[str]
    policy_status_code: Optional[int]
    received_mails: list[Mail] = field(default_factory=list)


@dataclass
class ModuleJ:
    """
    Results of test cases defined in Module J.
    """

    #: Positive test evaluating the ability of the TOE to successfully send a message
    #: to a remote MHS publishing a valid MTA-STS.
    j01: bool = False
    j01_mails: list[Mail] = field(default_factory=list)
    #: This test case checks the behavior of the TOE in case the remote MHS
    #: presents an expired X.509 certificate.
    j02: bool = False
    #: Mails received for the domain ZONE_MTASTS_EXPIRED_MHS_CERT
    j02_mails: list[Mail] = field(default_factory=list)
    #: This test case checks the behavior of the TOE in case the remote
    #: MHS X.509 certificate is untrusted by the TOE.
    j03: bool = False
    #: Mails received for the domain ZONE_MTASTS_UNTRUSTED_MHS
    j03_mails: list[Mail] = field(default_factory=list)
    #: This test case checks the behavior of the TOE in case the remote MHS
    #: X.509 certificate’s subject alternative name (SAN) [RFC5280] does not
    #: match the hostnames DNS-ID.
    j04: bool = False
    #: Mails received for the domain ZONE_MTASTS_NOMATCH_SAN
    j04_mails: list[Mail] = field(default_factory=list)
    compliant: bool = False


@dataclass
class PolicyEvaluation:
    policy: str = ""
    policy_dict: dict = field(default_factory=dict)
    valid: bool = False
    version_ok: bool = False
    mode: Optional[str] = None
    mode_ok: bool = False
    max_age_ok: bool = False
    missing_mxs: list[str] = field(default_factory=list)


@dataclass
class ModuleI:
    #: Positive test evaluating the presence and correctness of the MTASTS TXT
    #: Resource Record in the DNSSEC resolution of the service name of the MHS.
    i01: bool = False
    valid_records: list[TxtRecord] = field(default_factory=list)
    invalid_records: list[TxtRecord] = field(default_factory=list)
    #: Positive Test evaluating presence and secure provisioning of the MTA-STS
    #: policy referred by the MTA-STS TXT Resource Record.
    i02: bool = False
    #: TLS Analysis results for i02
    tls_analysis: Optional[TlsAnalysisResult] = None
    #: TLS Certificate of the policy server
    tls_cert: Optional[str] = None
    #: TLS Certificate subject
    tls_subject: Optional[dict] = None
    #: TLS Certificate issuer
    tls_issuer: Optional[dict] = None
    #: Positive Test evaluating the TOE enforces a MTA-STS policy.
    i03: bool = False
    #: The actual policy evaluation
    policy_evaluation: PolicyEvaluation = field(default_factory=PolicyEvaluation)
    compliant: bool = False


@dataclass
class MtaStsAnalyzeResult:
    """
    Results of the MTA-STS scanner's analysis
    """

    unique_id: str
    domain: str
    policy_subdomain: str
    #: Results of test Module I
    module_i: ModuleI = field(default_factory=ModuleI)
    #: Results of test Module J
    module_j: ModuleJ = field(default_factory=ModuleJ)


class MtaStsScanner(BaseScanner):
    """
    Perform MTA-STS Checks

    1. Query DNS for _mta-sts.{domain} TXT
    2. Query MTA-STS Policy via HTTPS mta-sts.{domain}/.well-known/mta-sts.txt
    3. Query MX records and validate them against mta-sts.txt
    """

    def _get_certificate(self, hostname) -> Optional[str]:
        try:
            port = 443
            conn = ssl.create_connection((hostname, port))
            context = ssl.SSLContext()
            sock = context.wrap_socket(conn, server_hostname=hostname)
            cert = ssl.DER_cert_to_PEM_cert(sock.getpeercert(True))
            sock.close()
            conn.close()
            return cert
        except Exception:
            return None

    def _download_policy(self, domain):
        """
        Raises:
            requests.RequestException
        """
        policy_url = f"https://{domain}/.well-known/mta-sts.txt"
        logger.info("Downloading MTA-STS policy from %s", policy_url)
        response = requests.get(policy_url, timeout=15)
        return response.text, response.status_code

    def scan(self):
        """
        Scan the MTA-STS implementation of an MHS
        """
        results = []
        for domain in self.environment.test_config.target.domains:
            logger.info("Querying MX %s", domain)
            domain_mxs = dnsviz_probe_rdtype(domain, "MX")
            query = f"_mta-sts.{domain}"
            logger.info("Querying TXT %s", query)
            probe = dnsviz_probe_rdtype(query, "TXT")
            txts = []
            for record in dnsviz_txt(probe):
                txts.append(TxtRecord(record, query=query))

            policy_subdomain = f"mta-sts.{domain}"
            policy_response = None
            policy_status_code = None
            tls_scan = None
            cert = None
            if len(txts) > 0:
                try:
                    policy_response, policy_status_code = self._download_policy(
                        policy_subdomain
                    )
                    tls_scan = tls_scan_host(policy_subdomain, "443")
                    cert = self._get_certificate(policy_subdomain)
                except (requests.RequestException, dns.exception.DNSException):
                    pass

            results.append(
                MtaStsScanResult(
                    domain=domain,
                    domain_mxs=domain_mxs,
                    sts_record=probe,
                    text_records=txts,
                    policy=policy_response,
                    policy_status_code=policy_status_code,
                    policy_subdomain=policy_subdomain,
                    tls_scan=tls_scan,
                    tls_cert=cert,
                    received_mails=list(
                        self.environment.mailstore.to_domain(
                            self.environment.ceti_config.zones.mtasts_valid_rr
                        )
                    )
                    + list(
                        self.environment.mailstore.to_domain(
                            self.environment.ceti_config.zones.mtasts_expired_mhs_cert
                        )
                    )
                    + list(
                        self.environment.mailstore.to_domain(
                            self.environment.ceti_config.zones.mtasts_nomatch_san
                        )
                    )
                    + list(
                        self.environment.mailstore.to_domain(
                            self.environment.ceti_config.zones.mtasts_untrusted_mhs
                        )
                    ),
                )
            )
        return results

    def _validate_record(self, record: TxtRecord) -> bool:
        """
        Check if the parsed STS record is valid

        Args:
            A TxtRecord

        Returns:
            bool - Indicating if the TxtRecord is a valid MTA-STS TXT Record.
        """
        return "v" in record and record["v"] == "STSv1" and "id" in record

    def _parse_policy(self, policy: str):
        """
        Parse a STS policy text to a dictionary
        """
        result = {}
        for line in policy.split("\n"):
            if len(line) > 0:
                # Lines are formatted HTTP-Header like
                # Key: Value
                line_split = line.split(":", maxsplit=1)
                if len(line_split) != 2:
                    # If a line does not follow this format, the policy is not ok.
                    return {}

                key, value = (
                    line_split[0].strip().lower(),
                    line_split[1].strip().lower(),
                )
                if not key in result:
                    result[key] = []

                result[key].append(value)
        return result

    def _evaluate_policy(self, scan_result: MtaStsScanResult) -> PolicyEvaluation:
        evaluation = PolicyEvaluation()
        evaluation.policy = scan_result.policy or ""
        evaluation.policy_dict = self._parse_policy(evaluation.policy)

        if (
            "version" in evaluation.policy_dict
            and "stsv1" in evaluation.policy_dict["version"]
        ):
            evaluation.version_ok = True

        if (
            "mode" in evaluation.policy_dict
            and len(evaluation.policy_dict["mode"]) == 1
        ):
            evaluation.mode = evaluation.policy_dict["mode"][0]
        if (
            "mode" in evaluation.policy_dict
            and "enforce" in evaluation.policy_dict["mode"]
        ):
            evaluation.mode_ok = True

        try:
            if "max_age" in evaluation.policy_dict and all(
                int(age) >= 1209600 for age in evaluation.policy_dict["max_age"]
            ):
                evaluation.max_age_ok = True
        except ValueError:
            pass

        for mx_domain in dnsviz_mx(scan_result.domain_mxs):
            found = False
            
            if "mx" in evaluation.policy_dict:
                for valid_mx in evaluation.policy_dict["mx"]:
                    if fnmatch.fnmatch(mx_domain, valid_mx):
                        found = True
                        break
            if not found:
                evaluation.missing_mxs.append(mx_domain)

        evaluation.valid = (
            evaluation.version_ok
            and evaluation.mode_ok
            and evaluation.max_age_ok
            and len(evaluation.missing_mxs) == 0
        )
        return evaluation

    def _analyze_inbound(self, scan_result: MtaStsScanResult):
        inbound = ModuleI()
        # Check if a valid DNS Record exists
        inbound.i01 = any(
            self._validate_record(record) for record in scan_result.text_records
        )
        inbound.valid_records = list(
            filter(self._validate_record, scan_result.text_records)
        )
        inbound.invalid_records = list(
            filter(
                lambda record: not self._validate_record(record),
                scan_result.text_records,
            )
        )

        # Analyze TLS
        if scan_result.tls_scan:
            inbound.tls_analysis = tls_analyze_invocation(scan_result.tls_scan)

        is_selfsigned = True
        # Evaluate Certificate
        if scan_result.tls_cert:
            cert = x509.load_pem_x509_certificate(
                str.encode(scan_result.tls_cert), default_backend()
            )
            inbound.tls_subject = cert.subject
            inbound.tls_issuer = cert.issuer
            inbound.tls_cert = scan_result.tls_cert
            is_selfsigned = cert.subject == cert.issuer
            common_names = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
            common_name = common_names[0] if len(common_names) > 0 else None
            san = None
            san_dns_names = []
            try:
                san = cert.extensions.get_extension_for_class(
                    x509.SubjectAlternativeName
                )
                san_dns_names = san.value.get_values_for_type(x509.DNSName)
            except ExtensionNotFound:
                pass

            name_valid = any(
                isinstance(name, str) and fnmatch.fnmatch(scan_result.policy_subdomain, name)
                for name in san_dns_names + [common_name]
            )
        else:
            name_valid = False

        inbound.i02 = (
            # <Text>The HTTP result code MUST be 200</Text>
            scan_result.policy_status_code == 200
            and (inbound.tls_analysis.is_conform if inbound.tls_analysis else False)
            # <Text>The HTTP service identifies itself using a X509 certificate.</Text>
            # <Text>The X509 certificate is not self-signed.</Text>
            and not is_selfsigned
            # <Text>The X509 certificate is valid for the host mta-sts.DOMAIN.</Text>
            and name_valid
        )

        # Evaluate Policy
        inbound.policy_evaluation = self._evaluate_policy(scan_result)
        inbound.i03 = (
            inbound.policy_evaluation.version_ok
            and inbound.policy_evaluation.mode_ok
            and inbound.policy_evaluation.max_age_ok
            and len(inbound.policy_evaluation.missing_mxs) == 0
        )

        inbound.compliant = inbound.i01 and inbound.i02 and inbound.i03

        return inbound

    def _analyze_outbound(self, scan_result: MtaStsScanResult) -> ModuleJ:
        outbound = ModuleJ()

        outbound.j01_mails = list(
            filter(
                lambda mail: mail.recipient.endswith(
                    "@" + self.environment.test_config.zones.mtasts_valid_rr
                ),
                scan_result.received_mails,
            )
        )
        outbound.j01 = len(outbound.j01_mails) > 0

        # TODO für j02 prüfen, ob Zertifikat wirklich abgelaufen ist. sonst kann hier keine Aussage
        # getroffen werden

        outbound.j02_mails = list(
            filter(
                lambda mail: mail.recipient.endswith(
                    "@" + self.environment.test_config.zones.mtasts_expired_mhs_cert
                ),
                scan_result.received_mails,
            )
        )
        outbound.j02 = len(outbound.j02_mails) == 0

        outbound.j03_mails = list(
            filter(
                lambda mail: mail.recipient.endswith(
                    "@" + self.environment.test_config.zones.mtasts_untrusted_mhs
                ),
                scan_result.received_mails,
            )
        )
        outbound.j03 = len(outbound.j03_mails) == 0

        outbound.j04_mails = list(
            filter(
                lambda mail: mail.recipient.endswith(
                    "@" + self.environment.test_config.zones.mtasts_nomatch_san
                ),
                scan_result.received_mails,
            )
        )
        outbound.j04 = len(outbound.j04_mails) == 0

        outbound.compliant = (
            outbound.j01 and outbound.j02 and outbound.j03 and outbound.j04
        )
        return outbound

    def analyze(self, results):
        analyze_results = []
        for scan_result in results.filter(MtaStsScanResult):
            inbound = self._analyze_inbound(scan_result)
            outbound = self._analyze_outbound(scan_result)

            res = MtaStsAnalyzeResult(
                domain=scan_result.domain,
                policy_subdomain=scan_result.policy_subdomain,
                module_i=inbound,
                module_j=outbound,
                unique_id=unique_id(),
            )
            analyze_results.append(res)
        return analyze_results
