"""
TLS Scanner

Scan the TLS implementation of all services given in the target configuration.
"""

import logging
from dataclasses import dataclass
from typing import Union

from ceti.api import (tls_analyze_clienthello, tls_analyze_invocation,
                      tls_scan_host)
from ceti.api.dnsviz import dnsviz_mx, dnsviz_probe_rdtype
from ceti.api.tls import SslScanInvocation, TlsAnalysisResult
from ceti.store import Mail

from .base import BaseScanner

logger = logging.getLogger(__name__)


@dataclass
class TlsScanResult:
    """
    The result of a TLS scan for a single server endpoint offering a TLS/STARTTLS service.
    """
    result: SslScanInvocation #: The result of the execution of sslscn
    service_type: str
    endpoint: str


@dataclass
class TlsMtaScanResult:
    result: SslScanInvocation #: The result of the execution of sslscn
    service_type: str
    endpoint: str


@dataclass
class TlsCollectedMailScanResult:
    """
    A TLS ClientHello handshake message collected for later analysis by the TlsScanner.
    """
    mail: Mail #: The mail containing the TLS ClientHello


@dataclass 
class TlsServicesAnalyzeResult:
    tls_analysis: TlsAnalysisResult
    service_type: str
    endpoint: str


@dataclass 
class TlsMTAAnalyzeResult:
    tls_analysis: TlsAnalysisResult
    service_type: str
    endpoint: str


@dataclass 
class TlsMailAnalyzeResult:
    tls_analysis: TlsAnalysisResult
    mail: Mail


@dataclass 
class OpportunisticFallBackAnalyzeResult:
    imap: tuple[list, list]
    smtp: tuple[list, list]
    pop3: tuple[list, list]
    is_compliant: bool


class TlsScanner(BaseScanner):
    """
    This scanner implements most of the test modules E and F.

    The only aspects not covered are autoconfig and autodiscover tests which are implemented in
    ceti.scanner.autoconfig.AutoconfigScanner.
    """

    def scan(self) -> Union[TlsScanResult, TlsCollectedMailScanResult, TlsMtaScanResult]:
        """
        Scan TLS services and collect client hello messages for later analysis

        Returns:
           A list of scan results that may be evaluated later. These scan results may be
           collected mails with a TLS client hello message :class:`TlsCollectedMailScanResult` or results from
           an sslscan execution :class:`TlsScanResult` or :class:`TlsMtaScanResult`.
        """
        results = []

        # scan client services inbound
        for service_type, endpoints in self.environment.test_config.target.services.items():

            for endpoint in endpoints:
                if not ":" in endpoint:
                    raise Exception("Service %s does not specify a port. Error in TargetConfiguration?", endpoint)
                host, port = endpoint.split(":", 1)
                
                logger.debug("TLS scan of %s", endpoint)
                
                results.append(TlsScanResult(
                    result=tls_scan_host(host, port, service_type),
                    service_type=service_type,
                    endpoint=endpoint,
                ))
        
        # scan MTA inbound
        mxs = []
        for domain in self.environment.test_config.target.domains:
            probe = dnsviz_probe_rdtype(domain, "MX")
            mxs.extend(dnsviz_mx(probe))
        
        for mx in set(mxs):
            endpoint = f"{mx}:25"
            logger.debug("TLS scan of %s", endpoint)
                
            results.append(TlsMtaScanResult(
                result=tls_scan_host(mx, 25, "starttls-smtp"),
                service_type="starttls-smtp",
                endpoint=endpoint,
            ))

        # scan mta outbound
        for mail in self.environment.mailstore.from_sender(self.environment.test_config.target.mail): 
            if mail.starttls:
                results.append(TlsCollectedMailScanResult(
                    mail=mail,
                ))
 
        return results

    def analyze(self, results):
        """
        Analyze TLS endpoints. This implements as well inbound as outbound test cases.

        To evaluate the TOE server's TLS implementation, the sslscan results
        :class:`ceti.api.SslScanInvocation` are considered. To evaluate the TOE as TLS client, collected
        mails with TLS ClientHello handshake messages :class:`TlsCollectedMailScanResult` are analyzed.

        Args:
            results (list): All scan results.

        Returns:
            A list containing a :class:`ceti.scanner.tls.TlsServicesAnalyzeResult`, 
            :class:`ceti.scanner.tls.TlsMailAnalyzeResult` or :class:`ceti.scanner.tls.OpportunisticFallBackAnalyzeResult`
            for each analyzed endpoint which may be a TLS server or TLS client.
        """

        analysis_results = []

        # analyze services inbound
        for scanresult in results.filter(TlsScanResult):
            scanresult: TlsScanResult = scanresult
            result = TlsServicesAnalyzeResult(
                service_type=scanresult.service_type,
                endpoint=scanresult.endpoint,
                tls_analysis=tls_analyze_invocation(scanresult.result)
            )
            analysis_results.append(result)

        # analyze MTA inbound
        for scanresult in results.filter(TlsMtaScanResult):
            scanresult: TlsScanResult = scanresult
            result = TlsMTAAnalyzeResult(
                service_type=scanresult.service_type,
                endpoint=scanresult.endpoint,
                tls_analysis=tls_analyze_invocation(scanresult.result)
            )
            analysis_results.append(result)

        # analyze MTA outbound
        for scanresult in results.filter(TlsCollectedMailScanResult):
            result = TlsMailAnalyzeResult(
                mail=scanresult.mail,
                tls_analysis=tls_analyze_clienthello(scanresult.mail)
            )
            analysis_results.append(result)

        
        def check_fallback(t):
            if len(t[0]) > 0:
                return len(t[1]) > 0
            return True

        services = self.environment.test_config.target.services
        
        imap = (services["tls-imap"], services["starttls-imap"])
        smtp = (services["tls-smtp"], services["starttls-smtp"])
        pop3 = (services["tls-pop3"], services["starttls-pop3"])

        fallback = OpportunisticFallBackAnalyzeResult(
            imap=imap,
            smtp=smtp,
            pop3=pop3,
            is_compliant = (check_fallback(imap) and check_fallback(pop3) and check_fallback(smtp))
        )

        analysis_results.append(fallback)

        return analysis_results
