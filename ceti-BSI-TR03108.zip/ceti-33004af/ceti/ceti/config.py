"""
This module allows accessing CETI's environment. This includes the configuration and access
to other software bundled with ceti like the mailserver(s), TLSRPT-HTTPS, the nameserver etc.
"""
import glob
import logging
import os
import os.path
from dataclasses import asdict, dataclass, field
from datetime import datetime
from os.path import join
from typing import Optional

import strictyaml
import yaml
from ceti.store import Mail, MailStore, TlsRptHttpsStore
from dacite import from_dict
from strictyaml import Bool, EmptyDict, EmptyList, EmptyNone, Int, Map
from strictyaml import Optional as OptionalY
from strictyaml import Seq, Str
from strictyaml.exceptions import YAMLSerializationError, YAMLValidationError

logger = logging.getLogger(__name__)


target_schema = Map(
    {
        "provider": Str(),
        "product": Str(),
        "mail": Str(),
        "domains": EmptyList() | Seq(Str()),
        OptionalY("remarks", default=None): EmptyNone() | Str(),
        OptionalY("organization_name", default=None): EmptyNone() | Str(),
        "services": Map(
            {
                "tls-smtp": EmptyList() | Seq(Str()),
                "tls-pop3": EmptyList() | Seq(Str()),
                "tls-imap": EmptyList() | Seq(Str()),
                "tls-http": EmptyList() | Seq(Str()),
                "starttls-smtp": EmptyList() | Seq(Str()),
                "starttls-pop3": EmptyList() | Seq(Str()),
                "starttls-imap": EmptyList() | Seq(Str()),
            }
        ),
    }
)


@dataclass
class TargetConfiguration:
    provider: str
    product: str
    mail: str
    domains: list[str]
    remarks: Optional[str] = None
    organization_name: Optional[str] = None
    services: dict[str, list[str]] = field(
        default_factory=lambda: {
            "tls-http": [],
            "tls-smtp": [],
            "tls-pop3": [],
            "tls-imap": [],
            "starttls-smtp": [],
            "starttls-imap": [],
            "starttls-pop3": [],   
        }
    )

    def __post_init__(self):
        self._initialized = True
        self._validate()

    def __setattr__(self, att, value):
        super().__setattr__(att, value)
        if hasattr(self, "_initialized"):
            self._validate()

    def _validate(self):
        try:
            strictyaml.as_document(asdict(self), target_schema)
        except (YAMLValidationError, YAMLSerializationError) as exception:
            raise ValidationError(exception.problem) from exception


ceti_schema = Map(
    {
        "target_path": Str(),
        "archive_path": Str(),
        "mailstore_paths": Seq(Str()),
        "tlsrpt_https_path": Str(),
        "dnsconfig_path": Str(),
        "debug": Bool(),
        "receive_wait_seconds": Int(),
        OptionalY("websocket_port", default=5000): Int(),
        OptionalY("webserver_public", default=None): EmptyNone() | Str(),
        "zones": EmptyDict()
        | Map(
            {
                "tlsrpt_valid": Str(),
                "tlsrpt_mailto": Str(),
                "tlsrpt_https": Str(),
                "tlsrpt_ver_none": Str(),
                "tlsrpt_ver_bad": Str(),
                "tlsrpt_rua_none": Str(),
                "tlsrpt_bad_negotiation": Str(),
                "tlsrpt_bad_policy": Str(),
                "tlsrpt_bad_general": Str(),
                "dnssec": Str(),
                "ksk_bad_sig": Str(),
                "expired_ksk": Str(),
                "dane": Str(),
                "tlsa_bad_sig": Str(),
                "tlsa_exp": Str(),
                "tlsas_ok": Str(),
                "tlsa_ca_cert": Str(),
                "sf_nmatch": Str(),
                "mtasts_valid_rr": Str(),
                "mtasts_expired_mhs_cert": Str(),
                "mtasts_untrusted_mhs": Str(),
                "mtasts_nomatch_san": Str(),
            }
        ),
    }
)


@dataclass
class ZoneConfiguration:
    # pylint: disable=too-many-instance-attributes
    tlsrpt_valid: str = "tlsrpt-mailto.tr03108.example.com"
    tlsrpt_mailto: str = "tlsrpt-mailto.tr03108.example.com"
    tlsrpt_https: str = "tlsrpt-https.tr03108.example.com"
    tlsrpt_ver_none: str = "tlsrpt-ver-none.tr03108.example.com"
    tlsrpt_ver_bad: str = "tlsrpt-ver-bad.tr03108.example.com"
    tlsrpt_rua_none: str = "tlsrpt-rua-none.tr03108.example.com"
    tlsrpt_bad_negotiation: str = "tlsrpt-bad-negotiation.tr03108.example.com"
    tlsrpt_bad_policy: str = "tlsrpt-bad-policy.tr03108.example.com"
    tlsrpt_bad_general: str = "tlsrpt-bad-general.tr03108.example.com"
    dnssec: str = "dnssec.tr03108.example.com"
    ksk_bad_sig: str = "ksk-bad-sig.tr03108.example.com"
    expired_ksk: str = "expired-ksk.tr03108.example.com"
    dane: str = "dane.tr03108.example.com"
    tlsa_bad_sig: str = "tlsa-bad-sig.tr03108.example.com"
    tlsa_exp: str = "tlsa-exp.tr03108.example.com"
    tlsas_ok: str = "tlsas-ok.tr03108.example.com"
    tlsa_ca_cert: str = "tlsa-ca-cert.tr03108.example.com"
    sf_nmatch: str = "sf-nmatch.tr03108.example.com"
    mtasts_valid_rr: str = "mtasts-valid-rr.tr03108.example.com"
    mtasts_expired_mhs_cert: str = "mtasts-expired-mhs-cert.tr03108.example.com"
    mtasts_untrusted_mhs: str = "mtasts-untrusted-mhs.tr03108.example.com"
    mtasts_nomatch_san: str = "mtasts-nomatch-san.tr03108.example.com"


@dataclass
class CetiConfiguration:
    """
    The CetiConfiguration contains the ceti environment's configuration. It allows access to the
    mailstore and tlsrpt-https store and defines the archive path, websocket port and so on.
    """

    # pylint: disable=too-many-instance-attributes
    target_path: str = "default-target.yaml"
    archive_path: str = "ceti-archive.yaml"
    tlsrpt_https_path: str = "/tlsrpt-https/tlsrpt.yaml"
    websocket_port: int = 5000
    dnsconfig_path: str = "/nameserver-config"
    webserver_public: Optional[str] = "/webserver-public"
    debug: bool = False
    #: Time to wait after the scanning has started to receive email and reports.
    receive_wait_seconds: int = 60 * 60 * 25 # Wait for 25 hours
    mailstore_paths: list[str] = field(
        default_factory=lambda: ["/mailserver/"]
    )
    zones: ZoneConfiguration = field(
        default_factory=ZoneConfiguration
    )

    def __post_init__(self):
        self._initialized = True
        self._validate()

    def __setattr__(self, att, value):
        super().__setattr__(att, value)
        if hasattr(self, "_initialized"):
            self._validate()

    def _validate(self):
        try:
            strictyaml.as_document(asdict(self), ceti_schema)
        except (YAMLValidationError, YAMLSerializationError) as exception:
            raise ValidationError(exception.problem) from exception


dnszone_schema = Map(
    {
        "testcase": EmptyNone() | Str(),
        "description": EmptyNone() | Str(),
    }
)


@dataclass
class DnsZone:
    """
    A DNS Zone configured in BIND 9 and its documentation.
    """

    zone: str
    zone_source: str
    description: Optional[str] = None
    testcase: Optional[str] = None


@dataclass
class TestConfiguration:
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    target: Optional[TargetConfiguration] = None
    dns_configuration: list[DnsZone] = field(default_factory=lambda: [])
    #
    zones: ZoneConfiguration = field(
        default_factory=ZoneConfiguration
    )


class ValidationError(Exception):
    pass


def load_ceti_config(ceticonfig_path: str) -> CetiConfiguration:

    logger.info("Loading CetiConfiguration from '%s'", ceticonfig_path)

    try:
        with open(ceticonfig_path, "r", encoding="utf-8") as yamlfile:
            configdata = strictyaml.load(yamlfile.read(), ceti_schema)
            config = from_dict(
                data_class=CetiConfiguration, data=configdata.data)
            return config
    except YAMLValidationError as exception:
        raise ValidationError(exception.problem) from exception


def save_ceti_config(ceticonfig_path: str, ceti_config: CetiConfiguration):

    logger.info("Saving CetiConfiguration to '%s'", ceticonfig_path)

    with open(ceticonfig_path, "w", encoding="utf-8") as yamlfile:
        yamldoc = strictyaml.as_document(asdict(ceti_config), ceti_schema)
        yamlfile.write(yamldoc.as_yaml())


def load_target_config(targetconfig_path: str) -> TargetConfiguration:

    logger.info("Loading TargetConfiguration from '%s'", targetconfig_path)

    with open(targetconfig_path, "r", encoding="utf-8") as yamlfile:
        return load_target_config_from_str(yamlfile.read())


def load_target_config_from_str(targetconfig_str: str) -> TargetConfiguration:
    try:
        configdata = strictyaml.load(targetconfig_str, target_schema)
        target = TargetConfiguration(**configdata.data)
        return target
    except YAMLValidationError as exception:
        raise ValidationError(exception.problem) from exception


def target_as_yaml(target: TargetConfiguration) -> str:
    yamldoc = strictyaml.as_document(asdict(target), target_schema)
    return yamldoc.as_yaml()


def save_target_config(targetconfig_path: str, target: TargetConfiguration):

    logger.info("Saving TargetConfiguration to '%s'", targetconfig_path)

    with open(targetconfig_path, "w", encoding="utf-8") as yamlfile:
        yamlfile.write(target_as_yaml(target))


def scrape_dns_configuration(dnsconfig_path: str) -> list[DnsZone]:
    zones = []
    for config in glob.iglob(f"{dnsconfig_path}/*.signed"):
        zonefile_path = config.removesuffix(".signed")
        with open(config, 'r', encoding='utf-8') as zone_file:
            zone_configuration = zone_file.read()
        zone = os.path.basename(zonefile_path)
        infofile_path = f"{zonefile_path}.info"
        info = {}
        if os.path.isfile(infofile_path):
            with open(infofile_path, "r", encoding="utf-8") as info_fp:
                try:
                    info = strictyaml.load(
                        info_fp.read(), dnszone_schema).data
                except YAMLValidationError as exception:
                    raise ValidationError(exception.problem) from exception

        zones.append(
            DnsZone(zone=zone, zone_source=zone_configuration, **info))

    return zones
