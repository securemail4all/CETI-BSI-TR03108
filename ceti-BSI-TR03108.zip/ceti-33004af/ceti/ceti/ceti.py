"""
This module implements the main part of ceti. It includes the public API in :class:`Ceti`, the
:class:`Manager` orchastrating the scanners and the :class:`ceti.archive.Archive` used to persist scan and
analyze results.
"""

import logging
from dataclasses import asdict
from datetime import datetime
import time

from .scanner.autodiscover_autoconfig import AutodiscoverAutoconfigScanner
from .scanner.dane import DaneScanner
from .scanner.mtasts import MtaStsScanner
from .scanner.tls import TlsScanner
from .scanner.tlsrpt import TlsRptScanner
from .utils.python import FilterableList, is_iterable
# from .writer.dbt import DbtWriter
from .writer.docbook_plain import DocbookPlainWriter

from .config import CetiConfiguration, TestConfiguration
from .environment import Environment
from .archive import Archive

logger = logging.getLogger(__name__)


class Manager:
    def __init__(self, archive, environment):
        self.scanner = []
        self.writer = []
        self.archive = archive
        self.environment = environment

    def add_scanner(self, scanner):
        self.scanner.append(scanner)

    def add_writer(self, writer):
        self.writer.append(writer)

    def scan(self):
        self.archive.clean_archive()
        self.environment.mailstore.clean()
        self.environment.tlsrpt_https_store.clean()
        self.environment.start_scanning()

        wtime = self.environment.ceti_config.receive_wait_seconds
        until = datetime.fromtimestamp(int(time.time()) + wtime)
        logger.info(
            "Send E-Mails to: %s",
            ", ".join(
                map(
                    lambda x: "test@" + x,
                    asdict(self.environment.ceti_config.zones).values(),
                )
            ),
        )
        logger.info("Waiting for incoming mails until %s ", until)
        time.sleep(wtime)

        for sc in self.scanner:
            logger.info("%s.scan()", sc.get_name())
            ret = sc.scan()
            if not is_iterable(ret):
                ret = [ret]
            for result in ret:
                self.archive.store(result)

        self.environment.finish_scanning()
        self.archive.store(self.environment.test_config)

    def analyze(self):
        analyze_result = FilterableList()
        archive = self.archive.load()

        for sc in self.scanner:
            logger.info("%s.analyze()", sc.get_name())
            ret = sc.analyze(archive)
            if not is_iterable(ret):
                ret = [ret]
            for result in ret:
                analyze_result.append(result)

        return analyze_result

    def build_reports(self, analyze_result):
        reports = []

        for wr in self.writer:
            logger.info("%s.build_reports()", wr.get_name())
            report = wr.build_report(analyze_result)
            reports.append(report)
        return reports


class Ceti:
    def __init__(self, ceti_config: CetiConfiguration):
        self.ceti_config = ceti_config

    def _get_default_manager(self, archive, environment):
        """
        Return the default manager executing all scanners
        """
        manager = Manager(archive, environment)

        manager.add_scanner(DaneScanner(environment))
        manager.add_scanner(MtaStsScanner(environment))
        manager.add_scanner(TlsScanner(environment))
        manager.add_scanner(TlsRptScanner(environment))
        manager.add_scanner(AutodiscoverAutoconfigScanner(environment))

        # manager.add_writer(DbtWriter(environment))
        manager.add_writer(DocbookPlainWriter(environment))

        return manager

    def create_new_reports(self):
        config = self.ceti_config

        env = Environment(config)
        archive = Archive(config.archive_path)
        manager = self._get_default_manager(archive, env)

        manager.scan()
        analyze_result = manager.analyze()
        reports = manager.build_reports(analyze_result)

        return reports

    def clean(self):
        config = self.ceti_config
        config.archive_path
        config.webserver_public

    def scan(self):
        """
        Execute all scanners and save their results to a new archive.

        Returns:
            The :class:`ceti.archive.Archive` containing the scan results
        """
        config = self.ceti_config
        env = Environment(config)
        archive = Archive(config.archive_path)

        manager = self._get_default_manager(archive, env)
        manager.scan()
        return archive

    def analyze(self):
        """
        Perform an analysis for an already scanned target.

        Parameters:
            archive (string): Path to a file containing the previous scan's result

        Returns:
            A :class:`ceti.utils.python.FilterableList` containing the analysis results.
        """
        config = self.ceti_config
        archive = Archive(config.archive_path)
        env = Environment(self.ceti_config, from_archive=archive)

        manager = self._get_default_manager(archive, env)
        analyze_result = manager.analyze()

        return analyze_result

    def render(self):
        """
        Perform an analysis for an already scanned target.

        Parameters:
            archive (string): Path to a file containing the previous scan's result

        Returns:
            A list[:class:`ceti.writer.report.BaseReport`] containing the rendered reports.
        """
        config = self.ceti_config
        archive = Archive(config.archive_path)
        env = Environment(self.ceti_config, from_archive=archive)

        manager = self._get_default_manager(archive, env)
        analyze_result = manager.analyze()
        reports = manager.build_reports(analyze_result)
        return reports
