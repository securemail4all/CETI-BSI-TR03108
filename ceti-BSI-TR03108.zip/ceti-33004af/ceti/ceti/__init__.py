"""
This is CETI
"""
