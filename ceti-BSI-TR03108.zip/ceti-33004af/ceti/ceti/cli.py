#! /usr/bin/env python3

import logging
import sys
import os
import click

from os.path import join

from .ceti import Ceti
from .config import load_ceti_config
from .config import CetiConfiguration
from ceti.wsserver import WSServer, WSLogHandler


def _setup_logging(debug):
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    stdout_logger = logging.StreamHandler(sys.stdout)
    stdout_logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter("%(module)8s %(levelname)7s - %(message)s")
    stdout_logger.setFormatter(formatter)
    root_logger.addHandler(stdout_logger)
    if debug:
        root_logger.setLevel(logging.DEBUG)
    else:
        root_logger.setLevel(logging.INFO)


@click.group()
def cli():
    pass


@cli.command()
@click.option("--config", default=None)
@click.option("--archive", default=None)
@click.option("--mail", default=None, multiple=True)
@click.option("--tlsrpt-https", default=None)
@click.option("--debug", default=False, is_flag=True)
@click.option(
    "--wait-seconds",
    envvar="WAIT_SECONDS",
    type=int,
    default=None,
    help="Seconds to wait for the environment to receive data "
    "from the DUT (environment variable WAIT_SECONDS)",
)
def websocket(config, archive, mail, tlsrpt_https, debug, wait_seconds):
    if config:
        ceti_config = load_ceti_config(config)
    else:
        ceti_config = CetiConfiguration()

    if debug is True:
        ceti_config.debug = True
    if archive:
        ceti_config.archive_path = archive
    if tlsrpt_https:
        ceti_config.tlsrpt_https_path = tlsrpt_https
    if mail:
        ceti_config.mailstore_paths = list(mail)
    if wait_seconds:
        ceti_config.receive_wait_seconds = wait_seconds

    _setup_logging(ceti_config.debug)

    server = WSServer(ceti_config)
    wslog = WSLogHandler(server)
    ceti_logger = logging.getLogger("ceti")
    ceti_logger.addHandler(wslog)
    
    if ceti_config.debug:
        ceti_logger.setLevel(logging.DEBUG)
    else:
        ceti_logger.setLevel(logging.INFO)

    server.start()


@cli.command()
@click.option("--target", required=True)
@click.option("--config", default=None)
@click.option("--archive", default=None)
@click.option("--mail", default=None, multiple=True)
@click.option("--tlsrpt-https", default=None)
@click.option("--outdir", default="/tmp/")
@click.option("--debug", default=False, is_flag=True)
@click.option(
    "--wait-seconds",
    type=int,
    default=0,
    help="Seconds to wait for the environment to receive data from the DUT",
)
def create_new_report(
    config, target, archive, mail, tlsrpt_https, outdir, debug, wait_seconds
):
    if not os.access(outdir, os.W_OK):
        sys.stderr.write(
            f"ERROR: outdir '{outdir}' is not writable or does not exist (exit)\n"
        )
        sys.exit(1)

    if config:
        ceti_config = load_ceti_config(config)
    else:
        ceti_config = CetiConfiguration()

    if debug is True:
        ceti_config.debug = True
    if archive:
        ceti_config.archive_path = archive
    if tlsrpt_https:
        ceti_config.tlsrpt_https_path = tlsrpt_https
    if mail:
        ceti_config.mailstore_paths = list(mail)
    ceti_config.receive_wait_seconds = wait_seconds

    ceti_config.target_path = target
    _setup_logging(ceti_config.debug)

    ceti = Ceti(ceti_config)
    reports = ceti.create_new_reports()
    for report in reports:
        fmt = report.format
        report.store(join(outdir, f"ceti-report-{fmt}/"))
        sys.stdout.write(
            f"SUCCESS: report saved to '{report.get_index_file_path()}\n' "
        )


@cli.command()
@click.option("--target", required=True)
@click.option("--config", default=None)
@click.option("--archive", default=None)
@click.option("--mail", default=None, multiple=True)
@click.option("--tlsrpt-https", default=None)
@click.option("--debug", default=False, is_flag=True)
@click.option(
    "--wait-seconds",
    type=int,
    default=0,
    help="Seconds to wait for the environment to receive data from the DUT",
)
def scan(config, target, archive, mail, tlsrpt_https, debug, wait_seconds):
    if config:
        ceti_config = load_ceti_config(config)
    else:
        ceti_config = CetiConfiguration()

    if debug is True:
        ceti_config.debug = True
    if archive:
        ceti_config.archive_path = archive
    if tlsrpt_https:
        ceti_config.tlsrpt_https_path = tlsrpt_https
    if mail:
        ceti_config.mailstore_paths = list(mail)
    ceti_config.receive_wait_seconds = wait_seconds

    ceti_config.target_path = target
    _setup_logging(ceti_config.debug)

    ceti = Ceti(ceti_config)
    ceti.scan()


@cli.command()
@click.option("--archive", default=None)
@click.option("--outdir", default="/tmp/")
@click.option("--debug", default=False, is_flag=True)
def render(archive, outdir, debug):
    if not os.access(outdir, os.W_OK):
        sys.stderr.write(
            f"ERROR: outdir '{outdir}' is not writable or does not exist (exit)\n"
        )
        sys.exit(1)

    ceti_config = CetiConfiguration()

    if archive:
        ceti_config.archive_path = archive
    if debug is True:
        ceti_config.debug = True

    _setup_logging(ceti_config.debug)

    ceti = Ceti(ceti_config)
    reports = ceti.render()

    for report in reports:
        fmt = report.format
        report.store(join(outdir, f"ceti-{fmt}/"))
        sys.stdout.write(f"SUCCESS: report saved to {report.get_index_file_path()}\n ")
