import importlib
import logging
import os
from dataclasses import asdict, is_dataclass

import dacite.exceptions
import yaml
from dacite import from_dict

from .config import TestConfiguration
from .utils.python import FilterableList

logger = logging.getLogger(__name__)


class Archive:

    def __init__(self, archive_file):
        self.archive_file = archive_file

        if os.path.isfile(archive_file):
            logger.info("Using existing archive file '%s'", archive_file)
        else:
            logger.info("Creating new archive file '%s'", archive_file)

        try:
            # touch the file and check write permission
            with open(archive_file, mode="a", encoding='utf-8'):
                pass
        except OSError as e:
            raise Exception(
                f"Failed to create archive file '{archive_file}'") from e
        
        self.loaded_archive = self._load_from_file()

    def clean_archive(self):
        logger.info("Cleaning archive '%s'", self.archive_file)
        
        self.loaded_archive = FilterableList()
        with open(self.archive_file, mode="w", encoding='utf-8'):
                pass

    def _module_name(self, instance):
        cls = instance.__class__
        return cls.__module__

    def _class_name(self, instance):
        cls = instance.__class__
        return cls.__name__

    def load_test_configuration(self):
        tstcfg = self.loaded_archive.filter(TestConfiguration)
        if len(tstcfg) != 1:
            raise Exception(f"Expected exactly one TestConfiguration in Archive (Got: {len(tstcfg)}).")
        
        return tstcfg[0]

    def store(self, result):
        if not is_dataclass(result):
            raise TypeError(
                f"{result.__class__} is not a dataclass (missing @dataclass decorator?)")

        logger.debug("Storing '%s' to archive.", self._class_name(result))

        self.loaded_archive.append(result)

        with open(self.archive_file, "a", encoding='utf-8') as archive:
            entry = {
                "modulename": self._module_name(result),
                "classname": self._class_name(result),
                "data": asdict(result)
            }
            yaml.safe_dump(entry, archive, explicit_start=True)

    def _load_from_file(self):
        results = FilterableList()

        with open(self.archive_file, "r", encoding='utf-8') as archive:
            yml = yaml.safe_load_all(archive)

            for entry in yml:
                try:
                    modulename = entry["modulename"]
                    classname = entry["classname"]
                    data = entry["data"]

                    module = importlib.import_module(modulename)
                    datacls = getattr(module, classname)
                except (ImportError, AttributeError, KeyError) as e:
                    raise Exception(
                        f"Archive file '{self.archive_file}' is corrupt.") from e

                if not is_dataclass(datacls):
                    raise TypeError(
                        f"{result.__class__} is not a dataclass (missing @dataclass decorator?)")

                logger.debug("Loading '%s' from archive.", datacls.__name__)

                try:
                    result = from_dict(data_class=datacls, data=data)
                except dacite.exceptions.DaciteError as exception:
                    raise Exception(f'Error loading archived result of type {datacls.__name__}') from exception
                
                results.append(result)
        return results

    def load(self):
        return self.loaded_archive