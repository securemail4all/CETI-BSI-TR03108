from typing import Optional
from datetime import datetime

import logging

from .config import (
    CetiConfiguration,
    TestConfiguration,
    load_target_config,
    scrape_dns_configuration,
)

from .store import MailStore, TlsRptHttpsStore

logger = logging.getLogger(__name__)


class Environment:
    def __init__(self, ceti_config: CetiConfiguration, from_archive=None):
        self.ceti_config = ceti_config

        if from_archive:
            # Load the test configuation from archive.
            self.test_config = from_archive.load_test_configuration()
            # Make sure that the zones that have been used
            # during the scan are configured.
            self.ceti_config.zones = self.test_config.zones
            # There is no mailstore or tlsrpt_https_store
            # available as we are running from an archive file.
            self.mailstore: Optional[MailStore] = None
            self.tlsrpt_https_store = None
        else:
            # Create a new TestConfiguration
            self.test_config = TestConfiguration()
            # Make sure that the zone configuration is saved
            # with the TestConfiguration
            self.test_config.zones = ceti_config.zones
            # Load the TargetConfiguration
            self.test_config.target = load_target_config(self.ceti_config.target_path)
            # Load the DNS server configuration
            # (primarily used for documentation purposes).
            self.test_config.dns_configuration = scrape_dns_configuration(
                self.ceti_config.dnsconfig_path
            )
            # Load MailStore and TlsRptHttpsStore
            self.mailstore = MailStore(self.ceti_config.mailstore_paths)
            self.tlsrpt_https_store = TlsRptHttpsStore(
                self.ceti_config.tlsrpt_https_path
            )

    def start_scanning(self):
        self.test_config.start_time = datetime.now().isoformat()
        self.test_config.dns_configuration = scrape_dns_configuration(
            self.ceti_config.dnsconfig_path
        )
        self.mailstore.whitelist(self.test_config.target.mail)

    def finish_scanning(self):
        self.test_config.end_time = datetime.now().isoformat()
