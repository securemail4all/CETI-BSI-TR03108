import itertools
import logging
import os
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Optional
from os.path import join
from ceti.utils.python import unique_id

import yaml
from filelock import FileLock

MAILSTORE_LOCK_FILE = "mailstore.lock"
TLSRPT_LOCK_FILE = "tlsrptstore.lock"

logger = logging.getLogger(__name__)

@dataclass
class Mail:
    # pylint: disable=too-many-instance-attributes
    clienthello: bytes
    clientip: str
    date: str
    dkim_key: bytes
    dkim_valid: bool
    message: bytes
    recipient: str
    sender: str
    starttls: bool
    clientport: int = -1
    internal_id: str = field(default_factory=unique_id)


class MailStore(Iterable):
    # pylint: disable=too-few-public-methods
    def __init__(self, paths):
        self.paths = paths
        
        for path in paths:
            if not os.access(path, os.W_OK):
                raise Exception(f"MailStore path '{path}' is not writeable or does not exist.")
        
    def to(self, recipient: str):
        """
        Find mails by recipient
        Returns:
            List of Mail
        """
        return filter(lambda mail: mail.recipient == recipient, self)

    def from_sender(self, sender: str):
        """
        Find mails by sender
        Returns:
            List of Mail
        """
        return filter(lambda mail: mail.sender == sender, self)

    def to_domain(self, domain: str):
        """
        Find mails by recipient domain
        Returns:
            List of Mail
        """
        return filter(lambda mail: mail.recipient.split('@', 1)[-1] == domain, self)

    def clean(self):
        for path in self.paths:
            logger.info("Cleaning MailStore '%s'" % path)
            with FileLock(join(path, MAILSTORE_LOCK_FILE), timeout=30):
                open(join(path, "whitelist"), "w").close()
                open(join(path, "mails.yaml"), "w").close()

    def whitelist(self, address):
        logger.info("Adding '%s' to mailserver whitelist" % address)
        for path in self.paths:
            with FileLock(join(path, MAILSTORE_LOCK_FILE), timeout=30):
                with open(join(path, "whitelist"), "a", encoding="utf-8") as f:
                    f.write(str(address) + "\n")

    def __iter__(self):
        result = []
        for path in self.paths:
            with FileLock(join(path, MAILSTORE_LOCK_FILE), timeout=30):
                with open(join(path, "mails.yaml"), "r", encoding="utf-8") as yamlfile:
                    docs = list(yaml.load_all(yamlfile, Loader=yaml.SafeLoader))
                    result.append(map(lambda doc: Mail(**doc), docs))
        return itertools.chain(*result).__iter__()


class TlsRptHttpsStore(Iterable):
    # pylint: disable=too-few-public-methods
    def __init__(self, path):
        self.path = path
        dirname = os.path.dirname(self.path)
        if not os.access(dirname, os.W_OK):
            raise Exception(f"TlsRptHttpsStore dir '{dirname}' is not writeable or does not exist.")

    def clean(self):
        logger.info("Cleaning TlsRptHttpsStore '%s'" % self.path)
        dirname = os.path.dirname(self.path)
        with FileLock(join(dirname, TLSRPT_LOCK_FILE), timeout=30):
            open(self.path, "w").close()

    def __iter__(self):
        dirname = os.path.dirname(self.path)
        with FileLock(join(dirname, TLSRPT_LOCK_FILE), timeout=30):
            with open(self.path, "r", encoding="utf-8") as yamlfile:
                docs = list(yaml.load_all(yamlfile, Loader=yaml.SafeLoader))
                return iter(docs)
