#include <argp.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/param.h>

#include <gnutls/dane.h>
#include <gnutls/pkcs11.h>

#include <json-c/json.h>


#define MAX_CLIST_SIZE 32
#define MAX_DATA_ENTRIES 100


const char *argp_program_version = "1.0";

struct arguments {
    char *args[3];
};

struct dane_query_st {
    struct ub_result *result;
    unsigned int data_entries;
    dane_cert_usage_t usage[MAX_DATA_ENTRIES];
    dane_cert_type_t type[MAX_DATA_ENTRIES];
    dane_match_type_t match[MAX_DATA_ENTRIES];
    gnutls_datum_t data[MAX_DATA_ENTRIES];
    unsigned int flags;
    dane_query_status_t status;
};


json_object* tlsa_rr_to_json(char *name, unsigned int usage, unsigned int type, unsigned int match, unsigned char *data, unsigned int verification, unsigned char *info) {

    json_object *tlsa_resource_record = json_object_new_object();

    json_object_object_add(tlsa_resource_record, "name", json_object_new_string(name));

    json_object *rdata = json_object_new_object();
    json_object_object_add(rdata, "certificateUsage", json_object_new_int(usage));
    json_object_object_add(rdata, "selector", json_object_new_int(type));
    json_object_object_add(rdata, "matchingType", json_object_new_int(match));
    json_object_object_add(rdata, "certificateAssociationData", json_object_new_string((char *)data));
    json_object_object_add(tlsa_resource_record, "rdata", rdata);

    json_object *result = json_object_new_object();
    json_object_object_add(result, "verification", json_object_new_boolean(verification));
    json_object_object_add(result, "info", json_object_new_string((char *)info));
    json_object_object_add(tlsa_resource_record, "result", result);

    return tlsa_resource_record;
}

int check(char *name, dane_state_t dane_state, dane_query_t dane_query, gnutls_datum_t certs[], unsigned int certs_size, json_object *jobj) {
    int i, ret;
    unsigned int usage, type, match;
    gnutls_datum_t data;
    unsigned long lbuffer_size = 1024;
    unsigned char *lbuffer = malloc(lbuffer_size);
    size_t size = lbuffer_size;

    json_object *tlsa_rrs = json_object_new_array();
    json_object_object_add(jobj, "tlsaResourceRecords", tlsa_rrs);
    for (i = 0; i < dane_query_entries(dane_query); i++) {
        ret = dane_query_data(dane_query, i, &usage, &type, &match, &data);
        if (ret < 0) goto error;

        ret = gnutls_hex_encode(&data, (void *) lbuffer, &size);
        if (ret < 0) goto error;

        struct dane_query_st x = {
            .data_entries = 1,
            .usage[0] = dane_query->usage[i],
            .type[0] = dane_query->type[i],
            .match[0] = dane_query->match[i],
            .data[0] = dane_query->data[i]
        };

        unsigned int status = 0;
        ret = dane_verify_crt_raw(dane_state, certs, certs_size, GNUTLS_CRT_X509, &x, 0, DANE_VFLAG_FAIL_IF_NOT_CHECKED, &status);
        if (ret < 0) {
            json_object_array_add(tlsa_rrs, tlsa_rr_to_json(name, usage, type, match, lbuffer, 0, (unsigned char *)dane_strerror(ret)));
            continue;
        }

        gnutls_datum_t out;
        ret = dane_verification_status_print(status, &out, 0);
        if (ret < 0) {
            json_object_array_add(tlsa_rrs, tlsa_rr_to_json(name, usage, type, match, lbuffer, 0, (unsigned char *)dane_strerror(ret)));
            continue;
        }
        json_object_array_add(tlsa_rrs, tlsa_rr_to_json(name, usage, type, match, lbuffer, status == 0, out.data));
        gnutls_free(out.data);
    }

    free(lbuffer);
    return 0;

error:
    free(lbuffer);
    return ret;
}

static error_t parse_opt (int key, char *arg, struct argp_state *state) {
    struct arguments *arguments = state->input;

    switch (key) {
        case ARGP_KEY_ARG:
            if (state->arg_num >= 3)
                argp_usage(state);
            arguments->args[state->arg_num] = arg;
            break;
        case ARGP_KEY_END:
            if (state->arg_num < 3)
                argp_usage(state);
            break;
        default:
            return ARGP_ERR_UNKNOWN;
    }
    return 0;
}

int main(int argc, char *argv[]) {
    static struct argp argp = { NULL, parse_opt, "HOST PORT CERT_FILE", NULL };
    struct arguments arguments;

    argp_parse(&argp, argc, argv, 0, 0, &arguments);

    char *host = arguments.args[0];
    int port = strtol(arguments.args[1], (char **)NULL, 10);
    char *cert_file = arguments.args[2];

    int ret, i;
    dane_state_t dane_state = NULL;
    dane_query_t dane_query = NULL;

    gnutls_datum_t cert_datum = { NULL };
    gnutls_x509_crt_t *clist = NULL;
    unsigned int clist_size;
    gnutls_datum_t certs[MAX_CLIST_SIZE] = { NULL };

    json_object *jobj = json_object_new_object();

    // init gnutls and dane

    ret = gnutls_global_init();
    if (ret < 0) goto error;

    ret = dane_state_init(&dane_state, DANE_F_IGNORE_LOCAL_RESOLVER);
    if (ret < 0) goto error;

    // query tls resource records

    ret = dane_query_tlsa(dane_state, &dane_query, host, "tcp", port);
    if (ret < 0) goto error;

    // load certificate

    ret = gnutls_load_file(cert_file, &cert_datum);
    if (ret < 0) goto error;

    ret = gnutls_x509_crt_list_import2(&clist, &clist_size, &cert_datum, GNUTLS_X509_FMT_PEM, 0);
    if (ret < 0) goto error;

    for (i = 0; i < MIN(MAX_CLIST_SIZE, clist_size); i++) {
        ret = gnutls_x509_crt_export2(clist[i], GNUTLS_X509_FMT_DER, &certs[i]);
        if (ret < 0) goto error;
    }

    // DANE check

    char name[256];
    snprintf(name, sizeof(name), "_%u._%s.%s.", port, "tcp", host);
    ret = check(name, dane_state, dane_query, certs, clist_size, jobj);
    if (ret < 0) goto error;

    goto cleanup;

error:
    json_object_object_add(jobj, "error", json_object_new_string(dane_strerror(ret)));

cleanup:
    printf("%s\n", json_object_to_json_string_ext(jobj, JSON_C_TO_STRING_PRETTY));

    json_object_put(jobj);

    gnutls_free(cert_datum.data);
    if (clist != NULL) {
        for (i = 0; i < clist_size; i++) {
            gnutls_free(certs[i].data);
            gnutls_x509_crt_deinit(clist[i]);
        }
        gnutls_free(clist);
    }

    if (dane_query != NULL) dane_query_deinit(dane_query);
    if (dane_state != NULL) dane_state_deinit(dane_state);

    gnutls_global_deinit();

    return ret;
}

