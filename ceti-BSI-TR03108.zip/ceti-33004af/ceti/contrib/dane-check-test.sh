#!/bin/bash

set -x

if [[ $# -lt 2 ]] ; then
    echo "usage: $0 <HOST> <PORT> [STARTTLS_PROTO]"
    exit 1
fi

HOST="$1"
PORT="$2"
STARTTLS_PROTO="${3:-}"

CERT_FILE=$(mktemp)

gnutls-cli --no-ca-verification --save-cert "$CERT_FILE" --starttls-proto "$STARTTLS_PROTO" --port "$PORT" "$HOST" </dev/null >/dev/null
[[ $? -eq 0 ]] || { ret=$?; echo "failed to obtain server certificate: $ret" >&2; rm $CERT_FILE; exit "$ret"; }

valgrind --leak-check=full -s ./dane-check "$HOST" "$PORT" "$CERT_FILE"
[[ $? -eq 0 ]] || { ret=$?; echo "DANE check failed: $ret" >&2; rm $CERT_FILE; exit "$ret"; }

rm $CERT_FILE
